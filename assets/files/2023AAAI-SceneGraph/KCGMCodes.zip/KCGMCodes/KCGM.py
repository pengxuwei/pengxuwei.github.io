import numpy as np
import math
import functools

import torch
import torch.nn as nn
from torch.nn import init
import torch.optim as optim
import torch.nn.functional as F
from torch.nn import Parameter as P
from beta_vae.solver import graphlabel_reconstruction_loss, kl_divergence, to_onehot
import layers
from sync_batchnorm import SynchronizedBatchNorm2d as SyncBatchNorm2d
from sklearn.metrics import precision_score, f1_score
from torch.optim.lr_scheduler import CosineAnnealingLR
from pygcn.layers import GraphConvolution

# Architectures for G
# Attention is passed in in the format '32_64' to mean applying an attention
# block at both resolution 32x32 and 64x64. Just '64' will apply at 64x64.
def G_arch(ch=64, attention='64', ksize='333333', dilation='111111'):
  arch = {}
  arch[512] = {'in_channels' :  [ch * item for item in [16, 16, 8, 8, 4, 2, 1]],
               'out_channels' : [ch * item for item in [16, 8, 8, 4, 2, 1, 1]],
               'upsample' : [True] * 7,
               'resolution' : [8, 16, 32, 64, 128, 256, 512],
               'attention' : {2**i: (2**i in [int(item) for item in attention.split('_')])
                              for i in range(3,10)}}
  arch[256] = {'in_channels' :  [ch * item for item in [16, 16, 8, 8, 4, 2]],
               'out_channels' : [ch * item for item in [16,  8, 8, 4, 2, 1]],
               'upsample' : [True] * 6,
               'resolution' : [8, 16, 32, 64, 128, 256],
               'attention' : {2**i: (2**i in [int(item) for item in attention.split('_')])
                              for i in range(3,9)}}
  arch[128] = {'in_channels' :  [ch * item for item in [16, 16, 8, 4, 2]],
               'out_channels' : [ch * item for item in [16, 8, 4, 2, 1]],
               'upsample' : [True] * 5,
               'resolution' : [8, 16, 32, 64, 128],
               'attention' : {2**i: (2**i in [int(item) for item in attention.split('_')])
                              for i in range(3,8)}}
  arch[64]  = {'in_channels' :  [ch * item for item in [16, 16, 8, 4]],
               'out_channels' : [ch * item for item in [16, 8, 4, 2]],
               'upsample' : [True] * 4,
               'resolution' : [8, 16, 32, 64],
               'attention' : {2**i: (2**i in [int(item) for item in attention.split('_')])
                              for i in range(3,7)}}
  arch[32]  = {'in_channels' :  [ch * item for item in [4, 4, 4]],
               'out_channels' : [ch * item for item in [4, 4, 4]],
               'upsample' : [True] * 3,
               'resolution' : [8, 16, 32],
               'attention' : {2**i: (2**i in [int(item) for item in attention.split('_')])
                              for i in range(3,6)}}

  return arch


class Generator(nn.Module):
  def __init__(self, Qhead, G_ch=64, dim_z=128, bottom_width=4, resolution=128,
               G_kernel_size=3, G_attn='64', n_classes=1000,
               num_G_SVs=1, num_G_SV_itrs=1,
               G_shared=True, shared_dim=0, hier=False,
               cross_replica=False, mybn=False,
               G_activation=nn.ReLU(inplace=False),
               G_lr=5e-5, G_B1=0.0, G_B2=0.999, adam_eps=1e-8,
               BN_eps=1e-5, SN_eps=1e-12, G_mixed_precision=False, G_fp16=False,
               G_init='ortho', skip_init=False, no_optim=False,
               G_param='SN', norm_style='bn', multilabel=False, CE=True,
               **kwargs):
    super(Generator, self).__init__()
    # Channel width mulitplier
    self.ch = G_ch
    # Dimensionality of the latent space
    self.dim_z = dim_z
    # The initial spatial dimensions
    self.bottom_width = bottom_width
    # Resolution of the output
    self.resolution = resolution
    # Kernel size?
    self.kernel_size = G_kernel_size
    # Attention?
    self.attention = G_attn
    # number of classes, for use in categorical conditional generation
    self.n_classes = n_classes
    # Use shared embeddings?
    self.G_shared = G_shared
    # Dimensionality of the shared embedding? Unused if not using G_shared
    self.shared_dim = shared_dim if shared_dim > 0 else dim_z
    # self.shared_dim = dim_z - n_classes
    # Hierarchical latent space?
    self.hier = hier
    # Cross replica batchnorm?
    self.cross_replica = cross_replica
    # Use my batchnorm?
    self.mybn = mybn
    # nonlinearity for residual blocks
    self.activation = G_activation
    # Initialization style
    self.init = G_init
    # Parameterization style
    self.G_param = G_param
    # Normalization style
    self.norm_style = norm_style
    # Epsilon for BatchNorm?
    self.BN_eps = BN_eps
    # Epsilon for Spectral Norm?
    self.SN_eps = SN_eps
    # fp16?
    self.fp16 = G_fp16
    # Architecture dict
    self.arch = G_arch(self.ch, self.attention)[resolution]

    # multilabel(nodes) for generation, as the baselime
    self.multilabel = multilabel
    # consider causality
    self.ce = CE
    self.Qnet = Qhead
    
    if self.multilabel:
      self.max_num_nodes = 62
      self.min_num_nodes = 2
      self.encode_z1 = layers.SNConv2d(self.min_num_nodes, 1, 1)
      # 295 is the max number of nodes (combining other catrgory information)
      self.encode_z2 = layers.SNConv2d(self.max_num_nodes, dim_z, 1)
    if self.ce:
      self.max_num_nodes = 64
      self.max_num_rels = 272
      self.max_attribute = 201
      self.max_node_label = 151
      self.max_rel_label = 51
      self.attribute_num = 10
      self.min_num_nodes = 4

    # If using hierarchical latents, adjust z
    if self.hier:
      # Number of places z slots into
      self.num_slots = len(self.arch['in_channels']) + 1
      self.z_chunk_size = (self.dim_z // self.num_slots)
      # Recalculate latent dimensionality for even splitting into chunks
      self.dim_z = self.z_chunk_size *  self.num_slots
    else:
      self.num_slots = 1
      self.z_chunk_size = 0

    # Which convs, batchnorms, and linear layers to use
    if self.G_param == 'SN':
      self.which_conv = functools.partial(layers.SNConv2d,
                          kernel_size=3, padding=1, num_svs=num_G_SVs, num_itrs=num_G_SV_itrs,
                          eps=self.SN_eps)
      self.which_linear = functools.partial(layers.SNLinear,
                          num_svs=num_G_SVs, num_itrs=num_G_SV_itrs,
                          eps=self.SN_eps)
    else:
      self.which_conv = functools.partial(nn.Conv2d, kernel_size=3, padding=1)
      self.which_linear = nn.Linear
      
    # We use a non-spectral-normed embedding here regardless;
    # For some reason applying SN to G's embedding seems to randomly cripple G
    self.which_embedding = nn.Embedding
    bn_linear = (functools.partial(self.which_linear, bias=False) if self.G_shared
                 else self.which_embedding)
    if self.multilabel:
      self.which_bn = functools.partial(layers.ccbn,
                            which_linear=bn_linear,
                            cross_replica=self.cross_replica,
                            mybn=self.mybn,
                            input_size=(self.shared_dim + self.z_chunk_size if self.G_shared
                                      else self.n_classes),
                            norm_style=self.norm_style,
                            eps=self.BN_eps, multilabel=self.multilabel, label_linear=nn.Linear)
    else:
      self.which_bn = functools.partial(layers.ccbn,
                            which_linear=bn_linear,
                            cross_replica=self.cross_replica,
                            mybn=self.mybn,
                            input_size=(self.shared_dim + self.z_chunk_size if self.G_shared
                                      else self.n_classes),
                            norm_style=self.norm_style,
                            eps=self.BN_eps)



    # Prepare model
    # If not using shared embeddings, self.shared is just a passthrough
    # claddified information embedding
    self.l_embed = self.which_embedding(self.max_node_label, self.min_num_nodes)
    self.r_embed = self.which_embedding(self.max_attribute, self.min_num_nodes)
    self.encode_r = self.which_linear(self.attribute_num*self.max_num_nodes*self.min_num_nodes, self.max_num_nodes*self.min_num_nodes)
    self.p_embed = self.which_embedding(self.max_rel_label, self.min_num_nodes)
    self.encode_p = self.which_linear(self.max_num_rels*self.min_num_nodes, self.max_num_nodes*self.min_num_nodes)

    

    self.dim_z_g = 128
    self.dim_z_l = 10
    self.dim_z_p = 16
    self.dim_z_r = 16
    self.hidden_feat = 128
    
    self.linear_node = self.which_linear((self.dim_z_r+self.dim_z_l+self.dim_z_p) // self.num_slots, int(self.arch['in_channels'][0]) * (self.bottom_width **2))

    self.gcn_g = GraphConv(in_features=self.max_num_nodes*2, out_features=int(self.arch['in_channels'][0] * (self.bottom_width **2)), adj_sq=False, scale_identity=False)

    ### if we apply double layer gcn, we have: 
    #  self.gcn_g2 = GraphConv(in_features=self.hidden_feat, out_features=int(self.arch['in_channels'][0] * (self.bottom_width **2)), adj_sq=False, scale_identity=False)
    ### for Z-GCN

    self.atten = self.which_linear(self.max_num_nodes*self.min_num_nodes*3, self.max_num_nodes*self.min_num_nodes)
    self.gcn_gc = GraphConv(in_features=self.max_num_nodes*self.min_num_nodes, out_features=self.max_num_nodes*self.min_num_nodes, adj_sq=False, scale_identity=False)

    ### we have:
    # self.gcn_gc2 = GraphConv(in_features=self.hidden_feat*2, out_features=self.max_num_nodes*self.min_num_nodes, adj_sq=False, scale_identity=False)
    ### for K-GCN
      
    self.atten = self.which_linear(self.max_num_nodes*self.min_num_nodes*3, self.max_num_nodes*self.min_num_nodes)
    # self.blocks is a doubly-nested list of modules, the outer loop intended
    # to be over blocks at a given resolution (resblocks and/or self-attention)
    # while the inner loop is over a given block
 
    self.blocks = []
    for index in range(len(self.arch['out_channels'])):
      self.blocks += [[layers.GBlock(in_channels=self.arch['in_channels'][index],
                             out_channels=self.arch['out_channels'][index],
                             which_conv=self.which_conv,
                             which_bn=self.which_bn,
                             activation=self.activation,
                             upsample=(functools.partial(F.interpolate, scale_factor=2)
                                       if self.arch['upsample'][index] else None))]]

      # If attention on this block, attach it to the end
      if self.arch['attention'][self.arch['resolution'][index]]:
        print('Adding attention layer in G at resolution %d' % self.arch['resolution'][index])
        self.blocks[-1] += [layers.Attention(self.arch['out_channels'][index], self.which_conv)]

    # Turn self.blocks into a ModuleList so that it's all properly registered.
    self.blocks = nn.ModuleList([nn.ModuleList(block) for block in self.blocks])

    # output layer: batchnorm-relu-conv.
    # Consider using a non-spectral conv here
    self.output_layer = nn.Sequential(layers.bn(self.arch['out_channels'][-1],
                                                cross_replica=self.cross_replica,
                                                mybn=self.mybn),
                                    self.activation,
                                    self.which_conv(self.arch['out_channels'][-1], 3))

    # Initialize weights. Optionally skip init for testing.
    if not skip_init:
      self.init_weights()

    # Set up optimizer
    # If this is an EMA copy, no need for an optim, so just return now
    if no_optim:
      return
    self.lr, self.B1, self.B2, self.adam_eps = G_lr, G_B1, G_B2, adam_eps
    if G_mixed_precision:
      print('Using fp16 adam in G...')
      import utils
      self.optim = utils.Adam16(params=self.parameters(), lr=self.lr,
                           betas=(self.B1, self.B2), weight_decay=0,
                           eps=self.adam_eps)
    else:
      self.optim = optim.Adam(params=self.parameters(), lr=self.lr,
                           betas=(self.B1, self.B2), weight_decay=0,
                           eps=self.adam_eps)

    # LR scheduling, left here for forward compatibility
    # self.lr_sched = {'itr' : 0}# if self.progressive else {}
    # self.j = 0
    self.scheduler = CosineAnnealingLR(self.optim,  150000)
  # Initialize
  def init_weights(self):
    self.param_count = 0
    for module in self.modules():
      if (isinstance(module, nn.Conv2d) 
          or isinstance(module, nn.Linear) 
          or isinstance(module, nn.Embedding)):
        if self.init == 'ortho':
          init.orthogonal_(module.weight)
        elif self.init == 'N02':
          init.normal_(module.weight, 0, 0.02)
        elif self.init in ['glorot', 'xavier']:
          init.xavier_uniform_(module.weight)
        else:
          print('Init style not recognized...')
        self.param_count += sum([p.data.nelement() for p in module.parameters()])
    print('Param count for G''s initialized parameters: %d' % self.param_count)

  # Note on this forward function: we pass in a y vector which has
  # already been passed through G.shared to enable easy class-wise
  # interpolation later. If we passed in the one-hot and then ran it through
  # G.shared in this forward function, it would be harder to handle.
  def forward(self, z_g, z_c_, targets=None):
    # latent variable transfom
    bz = z_g.shape[0]
    # If hierarchical, concatenate zs and ys
    if self.hier:
      zs = torch.split(z_g, self.z_chunk_size, 1)
      z_g = zs[0]
      ys = [torch.cat([z_c, item], 1) for item in zs[1:]]
    else:
      y_l = self.l_embed(targets[3]).view(bz, -1)
      y_r = self.encode_r(self.r_embed(targets[4]).view(bz, -1))
      y_p = self.encode_p(self.p_embed(targets[5]).view(bz, -1))

      y = self.atten(torch.cat([y_l, y_r, y_p], 1))
      y = self.gcn_gc(y.view(bz, self.max_num_nodes, -1), targets[1])
      # y = self.gcn_gc2(y.view(bz, self.max_num_nodes, -1), targets[1])

      ys = [y] * len(self.blocks)
      
    # First linear layer                              
    z_l, z_r, z_p = z_c_
    h_g =  self.gcn_g(z_g, targets[1])
    # h_g =  self.gcn_g2(h_g.view(bz, self.max_num_nodes, -1), targets[1])
    
    h_n = self.linear_node(torch.cat([z_l, z_r, z_p], 1))

    
    h = h_n * h_g
    # Reshape
    h = h.view(h.size(0), -1, self.bottom_width, self.bottom_width)
    
    # Loop over blocks
    for index, blocklist in enumerate(self.blocks):
      # Second inner loop in case block has multiple layers
      for block in blocklist:
        h = block(h, ys[index])
        
    # Apply batchnorm-relu-conv-tanh at output
    return torch.tanh(self.output_layer(h))
# Discriminator architecture, same paradigm as G's above
def D_arch(ch=64, attention='64',ksize='333333', dilation='111111'):
  arch = {}
  arch[256] = {'in_channels' :  [3] + [ch*item for item in [1, 2, 4, 8, 8, 16]],
               'out_channels' : [item * ch for item in [1, 2, 4, 8, 8, 16, 16]],
               'downsample' : [True] * 6 + [False],
               'resolution' : [128, 64, 32, 16, 8, 4, 4 ],
               'attention' : {2**i: 2**i in [int(item) for item in attention.split('_')]
                              for i in range(2,8)}}
  arch[128] = {'in_channels' :  [3] + [ch*item for item in [1, 2, 4, 8, 16]],
               'out_channels' : [item * ch for item in [1, 2, 4, 8, 16, 16]],
               'downsample' : [True] * 5 + [False],
               'resolution' : [64, 32, 16, 8, 4, 4],
               'attention' : {2**i: 2**i in [int(item) for item in attention.split('_')]
                              for i in range(2,8)}}
  arch[64]  = {'in_channels' :  [3] + [ch*item for item in [1, 2, 4, 8]],
               'out_channels' : [item * ch for item in [1, 2, 4, 8, 16]],
               'downsample' : [True] * 4 + [False],
               'resolution' : [32, 16, 8, 4, 4],
               'attention' : {2**i: 2**i in [int(item) for item in attention.split('_')]
                              for i in range(2,7)}}
  arch[32]  = {'in_channels' :  [3] + [item * ch for item in [4, 4, 4]],
               'out_channels' : [item * ch for item in [4, 4, 4, 4]],
               'downsample' : [True, True, False, False],
               'resolution' : [16, 16, 16, 16],
               'attention' : {2**i: 2**i in [int(item) for item in attention.split('_')]
                              for i in range(2,6)}}
  return arch

class Discriminator(nn.Module):

  def __init__(self, KNFN, D_ch=64, D_wide=True, resolution=128,
               D_kernel_size=3, D_attn='64', n_classes=1000,
               num_D_SVs=1, num_D_SV_itrs=1, D_activation=nn.ReLU(inplace=False),
               D_lr=2e-4, D_B1=0.0, D_B2=0.999, adam_eps=1e-8,
               SN_eps=1e-12, output_dim=1024, D_mixed_precision=False, D_fp16=False,
               D_init='ortho', skip_init=False, D_param='SN', multilabel=False, dim_node=2, max_num_nodes=64, max_num_rel=272, label_class_num=151, attr_class_num=201, pred_class_num=51, max_num_attr=10, ce=True, mid_k_output=(64,64,64), **kwargs):
    super(Discriminator, self).__init__()
    # Width multiplier
    self.ch = D_ch
    # Use Wide D as in BigGAN and SA-GAN or skinny D as in SN-GAN?
    self.D_wide = D_wide
    # Resolution
    self.resolution = resolution
    # Kernel size
    self.kernel_size = D_kernel_size
    # Attention?
    self.attention = D_attn
    # Number of classes
    self.n_classes = n_classes
    # Activation
    self.activation = D_activation
    # Initialization style
    self.init = D_init
    # Parameterization style
    self.D_param = D_param
    # Epsilon for Spectral Norm?
    self.SN_eps = SN_eps
    # Fp16?
    self.fp16 = D_fp16
    # Architecture
    self.arch = D_arch(self.ch, self.attention)[resolution]
    # multilabel classfication
    # modified by yang
    self.multilabel = multilabel
    # causal effect flag
    self.ce = ce
    # graph size configure
    self.max_num_attr = max_num_attr
    self.max_num_nodes = max_num_nodes
    self.max_num_rel = max_num_rel
    self.attr_class_num = attr_class_num
    self.label_class_num = label_class_num
    self.pred_class_num = pred_class_num
    self.dim_node = dim_node
    # knowledge as mid output
    self.mid_k_output = mid_k_output
    self.KNFN = KNFN

    # Which convs, batchnorms, and linear layers to use
    # No option to turn off SN in D right now
    if self.D_param == 'SN':
      self.which_conv = functools.partial(layers.SNConv2d,
                          kernel_size=3, padding=1,
                          num_svs=num_D_SVs, num_itrs=num_D_SV_itrs,
                          eps=self.SN_eps)
      self.which_linear = functools.partial(layers.SNLinear,
                          num_svs=num_D_SVs, num_itrs=num_D_SV_itrs,
                          eps=self.SN_eps)
      self.which_embedding = functools.partial(layers.SNEmbedding,
                              num_svs=num_D_SVs, num_itrs=num_D_SV_itrs,
                              eps=self.SN_eps)
    # Prepare model
    # self.blocks is a doubly-nested list of modules, the outer loop intended
    # to be over blocks at a given resolution (resblocks and/or self-attention)
    self.blocks = []
    for index in range(len(self.arch['out_channels'])):
      self.blocks += [[layers.DBlock(in_channels=self.arch['in_channels'][index],
                       out_channels=self.arch['out_channels'][index],
                       which_conv=self.which_conv,
                       wide=self.D_wide,
                       activation=self.activation,
                       preactivation=(index > 0),
                       downsample=(nn.AvgPool2d(2) if self.arch['downsample'][index] else None))]]
      
      # If attention on this block, attach it to the end
      if self.arch['attention'][self.arch['resolution'][index]]:
        print('Adding attention layer in D at resolution %d' % self.arch['resolution'][index])
        self.blocks[-1] += [layers.Attention(self.arch['out_channels'][index],
                                             self.which_conv)]
    # Turn self.blocks into a ModuleList so that it's all properly registered.
    self.blocks = nn.ModuleList([nn.ModuleList(block) for block in self.blocks])
    # Linear output layer. The output dimension is typically 1, but may be
    # larger if we're e.g. turning this into a VAE with an inference output
    self.linear = self.which_linear(self.arch['out_channels'][-1], output_dim)
    # self.linear2 = self.which_linear(self.arch['out_channels'][-1], output_dim)
    # Embedding for projection discrimination
    if self.multilabel:
      self.embed = self.which_embedding(self.n_classes, dim_node)
      self.final_node = self.which_linear(dim_node*max_num_nodes,self.arch['out_channels'][-1])
      self.final_adj = self.which_linear(relation_num**2, self.arch['out_channels'][-1])
    elif self.ce:
      self.max_num_nodes = 64
      self.max_num_rels = 272
      self.max_attribute = 201
      self.max_node_label = 151
      self.max_rel_label = 51
      self.attribute_num = 10
      self.min_num_nodes = 4

      self.l_embed = self.which_embedding(self.max_node_label, self.min_num_nodes)
      self.r_embed = self.which_embedding(self.max_attribute, self.min_num_nodes)
      self.encode_r = self.which_linear(self.attribute_num*self.max_num_nodes*self.min_num_nodes, self.max_num_nodes*self.min_num_nodes)
      self.p_embed = self.which_embedding(self.max_rel_label, self.min_num_nodes)
      self.encode_p = self.which_linear(self.max_num_rels*self.min_num_nodes, self.max_num_nodes*self.min_num_nodes)


      self.gcn_g = GraphConv(in_features=self.max_num_nodes*self.min_num_nodes, out_features=self.arch['out_channels'][-1], adj_sq=False, scale_identity=False)
      # double layer gcn
      # self.gcn_g2 = GraphConv(in_features=self.arch['out_channels'][-1], out_features=self.arch['out_channels'][-1], adj_sq=False, scale_identity=False)
      
      self.atten = self.which_linear(self.max_num_nodes*self.min_num_nodes*3, self.max_num_nodes*self.min_num_nodes)
      self.relu = nn.ReLU(True)
    else:  
      self.embed = self.which_embedding(self.n_classes, self.arch['out_channels'][-1])


    # Initialize weights
    if not skip_init:
      self.init_weights()

    # Set up optimizer
    self.lr, self.B1, self.B2, self.adam_eps = D_lr, D_B1, D_B2, adam_eps
    if D_mixed_precision:
      print('Using fp16 adam in D...')
      import utils
      self.optim = utils.Adam16(params=self.parameters(), lr=self.lr,
                             betas=(self.B1, self.B2), weight_decay=0, eps=self.adam_eps)
    else:
      self.optim = optim.Adam(params=self.parameters(), lr=self.lr,
                             betas=(self.B1, self.B2), weight_decay=0, eps=self.adam_eps)
    # LR scheduling, left here for forward compatibility
    # self.lr_sched = {'itr' : 0}# if self.progressive else {}
    # self.j = 0
    self.scheduler = CosineAnnealingLR(self.optim,  150000)

  # Initialize
  def init_weights(self):
    self.param_count = 0
    for module in self.modules():
      if (isinstance(module, nn.Conv2d)
          or isinstance(module, nn.Linear)
          or isinstance(module, nn.Embedding)):
        if self.init == 'ortho':
          init.orthogonal_(module.weight)
        elif self.init == 'N02':
          init.normal_(module.weight, 0, 0.02)
        elif self.init in ['glorot', 'xavier']:
          init.xavier_uniform_(module.weight)
        else:
          print('Init style not recognized...')
        self.param_count += sum([p.data.nelement() for p in module.parameters()])
    print('Param count for D''s initialized parameters: %d' % self.param_count)

  def forward(self, x, y=None, K=None, KR=None, train_G=False, train_vae=False):
    # Stick x into h for cleaner for loops without flow control
    h = x
    bz = x.shape[0]
    # Loop over blocks
    for index, blocklist in enumerate(self.blocks):
      for block in blocklist:
        h = block(h)
        if h[0].shape == self.mid_k_output:
          k_x = h
        
    # Apply global sum pooling as in SN-GAN
    h = torch.sum(self.activation(h), [2, 3])
    # Get initial class-unconditional output
    out = self.linear(h)
    # Get projection of final featureset onto class vectors and add to evidence
    if self.multilabel:
      # assert not self.final_adj is None
      out = out + torch.sum(self.final_node(self.embed(y).view(y.shape[0], -1)) * h, 1, keepdim=True) + torch.sum(self.final_adj(a.view(a.shape[0], -1)) * h, 1, keepdim=True)
    elif self.ce:
      e, a, _, l, r, p = y
      y_l = self.l_embed(l).view(bz, -1)
      y_r =  self.encode_r(self.r_embed(r).view(bz, -1))
      y_p =  self.encode_p(self.p_embed(p).view(bz, -1))
      y = self.atten(torch.cat([y_l, y_r, y_p], 1)) 
      hs = self.gcn_g(y.view(bz, self.max_num_nodes, -1), a) * h
      out = (out + hs).sum(1)
      
      # self attention mechanism
      if not train_G and not train_vae:
        k_x, _ = torch.split(k_x, [k_x.shape[0]-K[0][0].shape[0], K[0][0].shape[0]])
        K = [k_x] + K
        reconst_loss = self.KNFN(K)
        return out, reconst_loss, # reconst_loss_r, reconst_loss_rr
      else:
        K = [k_x] + K
        # Kr = [k_r] + KR
        reconst_loss = self.KNFN(K)
        # reconst_loss_r = self.KNFN(Kr)
        return out, reconst_loss
    else:
      out = out + torch.sum(self.embed(y) * h, 1, keepdim=True)
      return out
# Parallelized G_D to minimize cross-gpu communication
# Without this, Generator outputs would get all-gathered and then rebroadcast.


class VAES(nn.Module):
  def __init__(self, geVAE, BetaVAE, config):
    super(VAES, self).__init__()
    self.geVAE = geVAE
    self.BetaVAE_L = BetaVAE[0]
    self.BetaVAE_R = BetaVAE[1]
    self.BetaVAE_P = BetaVAE[2]


    self.max_num_nodes = config['max_num_nodes'] 
    self.max_num_rels = config['max_num_rels']
    self.config = config
    self.recons_loss = nn.MSELoss()


  def forward(self, graph, iter_, input_init, target_init, z_g_, C, train_geVAE=False, train_BetaVAE=False):

    (E, A, V, C_L, C_R, C_P) = graph
    (input_l, input_r, input_p) = input_init
    batch_size = E.shape[0]
    with torch.set_grad_enabled(train_geVAE):
      z_g, node_lp, edge_lp, k_g_e, k_g_d = self.geVAE(E, A, V)
      gevae_loss = -torch.mean((node_lp + edge_lp) / (V * (V - 1)))
      
      z_g_[:,:z_g.shape[1],:] = z_g
      z_g = z_g_.detach()
      k_g = [k_g_e.detach(), k_g_d.detach()]
    
    input_label = (C_L, C_R, C_P)
    with torch.set_grad_enabled(train_BetaVAE):
      n_num = input_label[0].shape[1]
      re_num = input_label[2].shape[1]
      beta_vae_loss = []
      z_cs = []
      k_cs = []
      
      for bidx in range(3):
        if bidx == 0:
          # L bvae
          distribution = 'gaussian'
          input_l[:,:n_num] = input_label[bidx]
          # 
          x_recon_l, mu, logvar, k_c_e_l, k_c_d_l, z_c_l = self.BetaVAE_L(input_l)
          recon_loss_l = graphlabel_reconstruction_loss(input_l, x_recon_l, distribution)
          total_kld, dim_wise_kld, mean_kld = kl_divergence(mu, logvar)
          knloss_l = self.recons_loss(k_c_e_l, k_c_d_l)
          beta_vae_loss_l = recon_loss_l + (self.config['gamma']+51)*(total_kld-C).abs() + 0.5*knloss_l
          C_L = input_l

        elif bidx == 1:
          # R bvae
          distribution = 'multilabel'
          device = input_label[bidx].device
          input_r[:,:,:n_num] = input_label[bidx]
          x_recon_r, mu, logvar, k_c_e_r, k_c_d_r, z_c_r = self.BetaVAE_R(input_r)
          recon_loss_r = graphlabel_reconstruction_loss(input_r, x_recon_r, distribution)
          total_kld, dim_wise_kld, mean_kld = kl_divergence(mu, logvar)
          knloss_r = self.recons_loss(k_c_e_r, k_c_d_r)
          beta_vae_loss_r = recon_loss_r + self.config['gamma']*(total_kld-C).abs()+ 0.3*knloss_r
          C_R = input_r
          # R accuracy
        elif bidx == 2:
          # P bvae
          distribution = 'gaussian'
          input_p[:,:re_num] = input_label[bidx]
          x_recon_p, mu, logvar, k_c_e_p, k_c_d_p, z_c_p = self.BetaVAE_P(input_p)
          recon_loss_p = graphlabel_reconstruction_loss(input_p, x_recon_p, distribution)
          total_kld, dim_wise_kld, mean_kld = kl_divergence(mu, logvar)
          knloss_p = self.recons_loss(k_c_e_p, k_c_d_p)
          beta_vae_loss_p = recon_loss_p + self.config['gamma']*(total_kld-C).abs() + 0.5*knloss_p
          C_P = input_p
      
      target_f = [E, A, V.long(), C_L, C_R, C_P]
      for tidx, g in enumerate(target_f):
          
        if tidx == 0:
          temp = target_init[tidx]
          temp[:,:E.shape[1],:] = E
          target_f[tidx] = temp

        elif tidx == 1:
          temp = target_init[tidx]
          temp[:,:A.shape[1],:A.shape[2]] = A
          target_f[tidx] = temp
        else:
          continue
      
      
      if train_BetaVAE and train_geVAE:
        torch.cuda.empty_cache()
        return gevae_loss, [beta_vae_loss_l, beta_vae_loss_r, beta_vae_loss_p, knloss_l+knloss_r+knloss_p], [input_l, input_r, input_p], [x_recon_l, x_recon_r, x_recon_p], k_g, [k_c_e_l, k_c_d_l], [k_c_e_r, k_c_d_r], [k_c_e_p, k_c_d_p], z_g, [z_c_l, z_c_r, z_c_p], target_f
      else:
        return target_f, z_g.detach(), [z_c_l.detach(), z_c_r.detach(), z_c_p.detach()], k_g, [k_c_e_l.detach(), k_c_d_l.detach()], [k_c_e_r.detach(), k_c_d_r.detach()], [k_c_e_p.detach(), k_c_d_p.detach()]

      
class G_D_CE(nn.Module):
  def __init__(self, G, D):
    super(G_D_CE, self).__init__()
    self.G = G
    self.D = D

  def forward(self, z_g, z_c, z_gr=None, z_cr=None, targets=None, v=None, z_rand=None, e=None, x=None, dy=None,
  K=None, KR=None, train_G=False, return_G_z=False, split_D=False, train_vae=False, a_init=None):              
    # If training G, enable grad tape
    with torch.set_grad_enabled(train_G):
      # Get Generator output given noise
      G_z = self.G(z_g, z_c, targets)
      
      # for knowledge
      if z_gr is not None:
        G_zr = self.G(z_gr, z_cr, targets)
      else:
        G_zr = None
      # Cast as necessary
      if self.G.fp16 and not self.D.fp16:
        G_z = G_z.float()
      if self.D.fp16 and not self.G.fp16:
        G_z = G_z.half()
    # Split_D means to run D once with real data and once with fake,
    # rather than concatenating along the batch dimension.
    if split_D:
      D_fake_dict = self.D(G_z, targets, K)
      D_fake = sum(loss for loss in D_fake_dict.values())
      if x is not None:
        D_real_dict = self.D(x, dy, K)
        D_real = sum(loss for loss in D_real_dict.values())
        return D_fake, D_real
      else:
        if return_G_z:
          return D_fake, G_z
        else:
          return D_fake
    # If real data is provided, concatenate it with the Generator's output
    # along the batch dimension for improved efficiency.
    else:
      G_z_ = G_z.reshape(G_z.shape[0], G_z.shape[1], x.shape[2], x.shape[3])if x is not None else G_z 
      
      D_input = torch.cat([G_z_, x], 0) if x is not None else G_z
      if dy is not None:
        D_class = []
        for ii, t in enumerate(targets):
          D_class.append(torch.cat([t, dy[ii]], 0))
      else:
        D_class = targets
      # Get Discriminator output
      if x is not None:
        D_out, knowledge = self.D(D_input, D_class, K=K)
        return torch.split(D_out, [G_z.shape[0], x.shape[0]]) + (knowledge,)
      else:  
        D_out, knowledge = self.D(D_input, D_class, K=K, train_G=train_G, train_vae=train_vae)
        
        if not train_vae:
          info_l, info_r, info_p, info_g = self.G.Qnet(knowledge[0], v, z_rand, e, a_init, train_bvae=False)
        else:
          info_l, info_r, info_p, info_g = None, None, None, None
        
        if return_G_z:
          return D_out, knowledge, [info_l, info_r, info_p, info_g], G_z
        else:
          return D_out, knowledge, [info_l, info_r, info_p, info_g]
     
      
class KNG_FN(nn.Module):
  def __init__(self, max_num_nodes, max_num_rels, knowledge_size=(64, 64), output_channel = 64, input_channel=[64, 64, 64, 272], lr=1e-3, device='cuda'):
    super(KNG_FN, self).__init__()
    self.max_num_nodes = max_num_nodes
    self.max_num_rels = max_num_rels
    
    self.f_a = nn.Sequential(
      nn.ConvTranspose2d(input_channel[0], 32, 4, 2, 1),
      nn.ReLU(True),
      nn.ConvTranspose2d(32, output_channel, 4, 2, 1), # B, output_channel, 64, 64
      nn.ReLU(True)
    )

    input_channel_ = sum(input_channel)

    self.f_l = nn.Sequential(
      nn.ConvTranspose2d(input_channel_, output_channel, 3, 1, 1),
      nn.ReLU(True)
    )
    self.reconstruct_loss = nn.L1Loss()
    self.device = device
    self.input_channel = input_channel
  
  def forward(self, k):
    k_x, k_g, k_c = k
    node_num = k_g[0].shape[1]
    bz = k_x.shape[0]
    k_g_e = F.normalize(k_g[0], p=2, dim=0)
    k_g_d = F.normalize(k_g[1], p=2, dim=0)
    input_g_size = int(np.sqrt(k_g[0].shape[2]))
    for i, tp in enumerate(k_c):
      k_c[i][0] = F.normalize(tp[0], p=2, dim=0)
      k_c[i][1] = F.normalize(tp[1], p=2, dim=0)
    
    k_y = torch.cat([self.f_a(k_g_e.view(bz, -1, input_g_size, input_g_size)), k_c[0][0], k_c[1][0], k_c[2][0]], 1)
    k_z = torch.cat([self.f_a(k_g_d.view(bz, -1, input_g_size, input_g_size)), k_c[0][1], k_c[1][1], k_c[2][1]], 1)

    k_y = self.f_l(k_y)
    k_z = self.f_l(k_z)

    return [k_x, k_y, k_z]

class KNG_FN64(nn.Module):
  def __init__(self, max_num_nodes, max_num_rels, knowledge_size=(64, 64), output_channel = 64, input_channel=[64, 64, 64, 272], lr=1e-3, device='cuda'):
    super(KNG_FN64, self).__init__()
    self.max_num_nodes = max_num_nodes
    self.max_num_rels = max_num_rels
    
    self.f_a = nn.Sequential(
      nn.ConvTranspose2d(input_channel[0], 32, 4, 2, 1),
      nn.ReLU(True),
      nn.ConvTranspose2d(32, output_channel, 4, 2, 1), # B, output_channel, 64, 64
      nn.ReLU(True)
    )

    input_channel_ = sum(input_channel)
    self.f_x = nn.Sequential(
      nn.ConvTranspose2d(input_channel[0], output_channel, 4, 2, 1),
      nn.ReLU(True)
    )
    self.f_l = nn.Sequential(
      nn.ConvTranspose2d(input_channel_, output_channel, 3, 1, 1),
      nn.ReLU(True)
    )
    self.reconstruct_loss = nn.L1Loss()
    self.device = device
    self.input_channel = input_channel
  
  def forward(self, k):
    k_x, k_g, k_c = k
    node_num = k_g[0].shape[1]
    bz = k_x.shape[0]
    k_g_e = F.normalize(k_g[0], p=2, dim=0)
    k_g_d = F.normalize(k_g[1], p=2, dim=0)
    input_g_size = int(np.sqrt(k_g[0].shape[2]))
    for i, tp in enumerate(k_c):
      k_c[i][0] = F.normalize(tp[0], p=2, dim=0)
      k_c[i][1] = F.normalize(tp[1], p=2, dim=0)
    
    k_y = torch.cat([self.f_a(k_g_e.view(bz, -1, input_g_size, input_g_size)), k_c[0][0], k_c[1][0], k_c[2][0]], 1)
    k_z = torch.cat([self.f_a(k_g_d.view(bz, -1, input_g_size, input_g_size)), k_c[0][1], k_c[1][1], k_c[2][1]], 1)

    k_y = self.f_l(k_y)
    k_z = self.f_l(k_z)
    k_x = self.f_x(k_x)
    return [k_x, k_y, k_z]

class Qhead(nn.Module):  
  def __init__(self, BetaVAE, GVAE):
    super(Qhead, self).__init__()
    self.GVAE = GVAE
    self.BetaVAE_L = BetaVAE[0]
    self.BetaVAE_R = BetaVAE[1]
    self.BetaVAE_P = BetaVAE[2]
    self.conv_gvae = nn.Sequential(
      nn.Conv2d(64, 64, 1),
    )
    
    self.max_num_nodes = BetaVAE[0].max_num_nodes
    self.max_num_rels = BetaVAE[0].max_num_rels

    self.conv_bvael = nn.Sequential(
      nn.Conv2d(64, self.max_num_nodes, 1),
      nn.BatchNorm2d(self.max_num_nodes),
    )
    self.conv_bvaer = nn.Sequential(
      nn.Conv2d(64, 32, 1, 1),
      nn.BatchNorm2d(32),
      nn.Conv2d(32, 32, 1, 1),
      nn.BatchNorm2d(32),
      nn.Conv2d(32, self.max_num_nodes, 1),
      nn.BatchNorm2d(self.max_num_nodes),
    )
    self.conv_bvaep = nn.Sequential(
      nn.Conv2d(64, self.max_num_rels, 1),
      nn.BatchNorm2d(self.max_num_rels),
    )
  def forward(self, k, v, z_rand, e, a_init, train_bvae=True):
    kg = self.conv_gvae(k)
    kl = self.conv_bvael(k)
    kr = self.conv_bvaer(k)
    kp = self.conv_bvaep(k)
    with torch.set_grad_enabled(train_bvae):
      pred_l, mu_l, logvar_l = self.BetaVAE_L.decoder_forward(kl)
      pred_r, mu_r, logvar_r = self.BetaVAE_R.decoder_forward(kr)
      pred_p, mu_p, logvar_p = self.BetaVAE_P.decoder_forward(kp)
      A_rec, _, V = self.GVAE.reconstruct_from_k_g(kg, v, z_rand, e, a_init)
    
      z_g, node_loss, node_loss, _, _ = self.GVAE.forward(e, A_rec, V)
    
      loss_A = -torch.mean((node_loss+node_loss) / (v*(v-1)))

    return  [pred_l, mu_l, logvar_l], [pred_r, mu_r, logvar_r], [pred_p, mu_p, logvar_p], [loss_A, z_g]
    

class GraphConv(nn.Module):
  '''
  Graph Convolution Layer according to (T. Kipf and M. Welling, ICLR 2017)
  Additional tricks (power of adjacency matrix and weight self connections) as in the Graph U-Net paper
  '''
  def __init__(self, 
              in_features,
              out_features,
              activation=None,
              adj_sq=False,
              scale_identity=False, device='cuda'):
    super(GraphConv, self).__init__()
    self.fc = nn.Linear(in_features=in_features, out_features=out_features)
    self.adj_sq = adj_sq
    self.activation = activation
    self.scale_identity = scale_identity
    self.device = device
            
  def laplacian_batch(self, A):
    batch, N = A.shape[:2]
    if self.adj_sq:
      A = torch.bmm(A, A)  # use A^2 to increase graph connectivity
    I = torch.eye(N).unsqueeze(0).to(self.device)
    if self.scale_identity:
      I = 2 * I  # increase weight of self connections
    A_hat = A + I
    D_hat = (torch.sum(A_hat, 1) + 1e-5) ** (-0.5)
    L = D_hat.view(batch, N, 1) * A_hat * D_hat.view(batch, 1, N)
    return L

  def forward(self, x, A):
    x = self.fc(torch.bmm(self.laplacian_batch(A), x).view(x.shape[0], -1))
    if self.activation is not None:
        x = self.activation(x)
    return x