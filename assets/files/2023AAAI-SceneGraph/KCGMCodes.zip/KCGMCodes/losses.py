import torch
import torch.nn.functional as F
import torch.nn as nn

# DCGAN loss
def loss_dcgan_dis(dis_fake, dis_real):
  L1 = torch.mean(F.softplus(-dis_real))
  L2 = torch.mean(F.softplus(dis_fake))
  return L1, L2


def loss_dcgan_gen(dis_fake):
  loss = torch.mean(F.softplus(-dis_fake))
  return loss


# Hinge Loss
def loss_hinge_dis(dis_fake, dis_real):
  loss_real = torch.mean(F.relu(1. - dis_real))
  loss_fake = torch.mean(F.relu(1. + dis_fake))
  return loss_real, loss_fake


def tril1loss(x, y, z):
  assert x.shape == y.shape
  assert z.shape == x.shape
  return torch.mean(torch.abs(x - y) + torch.abs(z - x))

def tril2loss(x, y, z):
  lxy = nn.MSELoss()(x, y)
  lxz = nn.MSELoss()(x, z)
  return lxy + lxz

def tri_bce_loss(x, y, z):
  target_y = nn.LogSoftmax(dim=1)(y).argmax(1)
  pred_x = nn.LogSoftmax(dim=1)(x)
  lxy = nn.NLLLoss()(pred_x, target_y)

  target_z = nn.LogSoftmax(dim=1)(z).argmax(1)
  pred_x = nn.LogSoftmax(dim=1)(x)
  lxz = nn.NLLLoss()(pred_x, target_z)

  return 0.5*lxy+0.5*lxz
  

def loss_hinge_gen(dis_fake):
  loss = -torch.mean(dis_fake)
  return loss

def loss_bce_dis(dis_fake, dis_real, target_real, target_fake):
  loss_real = torch.mean(F.sigmoid(target_real - dis_real))
  loss_fake = torch.mean(F.sigmoid(target_fake - dis_fake))
  return loss_real, loss_fake

# # Default to hinge loss
generator_loss = loss_hinge_gen
discriminator_loss = loss_hinge_dis

# discriminator_loss = loss_dcgan_dis
# generator_loss = loss_dcgan_gen
