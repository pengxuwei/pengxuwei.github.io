#! /bin/sh

CUDA_VISIBLE_DEVICES=2 python main.py --dataset vg --seed 101 --lr 1e-3 --beta1 0.9 --beta2 0.999 \
    --objective B --model G_R --batch_size 64 --z_dim 16 --max_iter 1.5e6 \
    --C_stop_iter 1e5 --C_max 16 --gamma 100 --viz_name vg_B_gamma100_z16attr \
