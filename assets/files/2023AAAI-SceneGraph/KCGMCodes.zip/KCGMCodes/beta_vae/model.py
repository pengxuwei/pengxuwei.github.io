"""model.py"""
"""
we have tried to build the model of different graphic components to share weights, the model has difficulty converging
"""
import torch
import torch.nn as nn
#import torch.nn.functional as F
import torch.nn.init as init
from torch.autograd import Variable
import layers
import functools
import torch.nn.functional as F
import torch.optim as optim

def reparametrize(mu, logvar):
    std = logvar.div(2).exp()
    eps = Variable(std.data.new(std.size()).normal_())
    return mu + std*eps


class View(nn.Module):
    def __init__(self, size):
        super(View, self).__init__()
        self.size = size

    def forward(self, tensor):
        return tensor.view(self.size)


class BetaVAE_H(nn.Module):
    """Model proposed in original beta-VAE paper(Higgins et al, ICLR, 2017)."""

    def __init__(self, z_dim=10, nc=3):
        super(BetaVAE_H, self).__init__()
        self.z_dim = z_dim
        self.nc = nc
        self.encoder = nn.Sequential(
            nn.Conv2d(nc, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.ReLU(True),
            nn.Conv2d(32, 64, 4, 2, 1),          # B,  64,  8,  8
            nn.ReLU(True),
            nn.Conv2d(64, 64, 4, 2, 1),          # B,  64,  4,  4
            nn.ReLU(True),
            nn.Conv2d(64, 256, 4, 1),            # B, 256,  1,  1
            nn.ReLU(True),
            View((-1, 256*1*1)),                 # B, 256
            nn.Linear(256, z_dim*2),             # B, z_dim*2
        )
        self.decoder = nn.Sequential(
            nn.Linear(z_dim, 256),               # B, 256
            View((-1, 256, 1, 1)),               # B, 256,  1,  1
            nn.ReLU(True),
            nn.ConvTranspose2d(256, 64, 4),      # B,  64,  4,  4
            nn.ReLU(True),
            nn.ConvTranspose2d(64, 64, 4, 2, 1), # B,  64,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(64, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, nc, 4, 2, 1),  # B, nc, 64, 64
        )

        self.weight_init()

    def weight_init(self):
        for block in self._modules:
            for m in self._modules[block]:
                kaiming_init(m)

    def forward(self, x):
        distributions = self._encode(x)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)
        x_recon = self._decode(z)

        return x_recon, mu, logvar

    def _encode(self, x):
        return self.encoder(x)

    def _decode(self, z):
        return self.decoder(z)


class BetaVAE_B(BetaVAE_H):
    """Model proposed in understanding beta-VAE paper(Burgess et al, arxiv:1804.03599, 2018)."""

    def __init__(self, z_dim=10, nc=1):
        super(BetaVAE_B, self).__init__()
        self.nc = nc
        self.z_dim = z_dim

        self.encoder = nn.Sequential(
            nn.Conv2d(nc, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  8,  8
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  4,  4
            nn.ReLU(True),
            View((-1, 32*4*4)),                  # B, 512
            nn.Linear(32*4*4, 256),              # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, z_dim*2),             # B, z_dim*2
        )

        self.decoder = nn.Sequential(
            nn.Linear(z_dim, 256),               # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, 32*4*4),              # B, 512
            nn.ReLU(True),
            View((-1, 32, 4, 4)),                # B,  32,  4,  4
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, nc, 4, 2, 1), # B,  nc, 64, 64
        )
        self.weight_init()

    def weight_init(self):
        for block in self._modules:
            for m in self._modules[block]:
                kaiming_init(m)

    def forward(self, x):
        distributions = self._encode(x)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)
        x_recon = self._decode(z).view(x.size())

        return x_recon, mu, logvar

    def _encode(self, x):
        return self.encoder(x)

    def _decode(self, z):
        return self.decoder(z)

class BetaVAE_G(BetaVAE_B):
    """To model the graph label information
    """
    def __init__(self, z_dim=10, nc=1, max_num_nodes=62, max_num_rels=272, nlabel=151, nattr=201, npred=51):
        super(BetaVAE_G, self).__init__()
        # the number of the channel?
        self.nc = nc
        self.z_dim = z_dim
        num_D_SVs = 1
        num_D_SV_itrs = 1
        SN_eps = 1e-12
        self.which_embedding = functools.partial(layers.SNEmbedding, num_svs=num_D_SVs, num_itrs=num_D_SV_itrs, eps=SN_eps)
        
        self.nc = nc
        self.max_num_nodes = max_num_nodes
        self.max_num_rels = max_num_rels
        
        self.embed_L = self.which_embedding(nlabel, nc)
        self.embed_R = self.which_embedding(nattr, nc)
        self.embed_P = self.which_embedding(npred, nc)
        self.fuse_l = nn.Sequential(
            nn.Linear(max_num_nodes*(nc+1)*nc, 512),
            nn.ReLU(True)
            )
        self.fuse_p = nn.Sequential(
            nn.Linear(max_num_rels*nc, 512)
        )
        self.encoder_d_l = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes, 4, 2, 1), # B,  nc, 64, 64
            nn.ReLU(True),
        )
        self.encoder_d_p = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_rels, 4, 2, 1), # B,  nc, 64, 64
            nn.ReLU(True),
        )
        # output is the knowledge K_y

        self.encoder_e = nn.Sequential(
            nn.Conv2d(self.max_num_nodes+self.max_num_rels, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  8,  8
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  4,  4
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            View((-1, 32*4*4)),
            nn.Linear(512, z_dim*2),
        )
        self.decoder_d = nn.Sequential(
            nn.Linear(z_dim, 256),              # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, 32*4*4),             # B, 32, 4, 4
            nn.ReLU(True),
            View((-1, 32, 4, 4)),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes+self.max_num_rels, 4, 2, 1), # B,  32, 64, 64
            nn.ReLU(True),
        )
        # output of knowledge K_z

        self.decoder_e_l = nn.Sequential(
            nn.Conv2d(self.max_num_nodes, 32, 4, 2, 1),  # B,  32, 32, 32  
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),  # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),  # B,  32, 8, 8
            nn.BatchNorm2d(32),
            nn.ReLU(True),
        )


        self.disentangle_1 = nn.Conv2d(32, self.max_num_nodes, 4, 2, 1)   # B,  1364,  4,  4
        # self.disentangle_2 = nn.Conv2d(32, 867, 4, 2, 1)  # B,  867,  4,  4
        self.weight_init()
    
    def weight_init(self):
        for module in self._modules:
            if (isinstance(self._modules[module], nn.Sequential)):
               for m in self._modules[module]:
                   if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear) or isinstance(self._modules[module], nn.ConvTranspose2d)):
                        # init.xavier_uniform_(m.weight)
                        kaiming_init(m)
            if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear)):
                # init.xavier_uniform_(self._modules[module].weight) 
                init.kaiming_normal(self._modules[module].weight)
                # init.normal_(self._modules[module].weight, 0, 0.02)
            elif isinstance(self._modules[module], (nn.BatchNorm1d, nn.BatchNorm2d)):
                self._modules[module].weight.data.fill_(1)
                if self._modules[module].bias is not None:
                    self._modules[module].bias.data.fill_(0)
    def forward(self, x):
        # (C_L, C_R, C_P, index)
        L = x[0]
        R = x[1]
        P = x[2]
        batchsize = L.shape[0]
        L_embed = self.embed_L(L)
        R_embed = self.embed_R(R)
        P_embed = self.embed_P(P)
        batchsize = L_embed.shape[0]

        # fuse the two categorical information
        L_R_embed = torch.cat((L_embed.view(-1, self.nc, self.max_num_nodes, 1),R_embed), 3)

        output_l = self.fuse_l(L_R_embed.view(batchsize, -1))
        output_p = self.fuse_p(P_embed.view(batchsize, -1))

        # forward
        K_c_l = self.encoder_d_l(output_l.view(-1, 32, 4, 4)) 
        K_c_p = self.encoder_d_p(output_p.view(-1, 32, 4, 4))
        K_c = torch.cat((K_c_l, K_c_p), 1)
        distributions = self.encoder_e(K_c)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)

        K_c_ = self.decoder_d(z)
        x_l = self.decoder_e_l(K_c_[:, :self.max_num_nodes,:,:])
        lr_logprob = self.disentangle_1(x_l).view(-1, 62, 201+151)
        L_prob =  lr_logprob[:,:,:151]
        R_prob =  lr_logprob[:,:,151:]
        x_p = self.decoder_e_p(K_c_[:, self.max_num_nodes:,:,:])

        P_prob =  self.disentangle_2(x_p).view(-1, 272, 51)
        
        return L_prob, R_prob, P_prob, mu, logvar, K_c, K_c_

class BetaVAE_G_L(BetaVAE_B):
    """To model the graph label information
    """
    def __init__(self, z_dim=10, nc=10, lr=1e-5, beta1=0.9, beta2=0.99, max_num_nodes=64, max_num_rels=272, nlabel=151, nattr=201, npred=51):
        super(BetaVAE_G_L, self).__init__()
        # the number of the channel?
        self.nc = nc
        self.z_dim = z_dim
        num_D_SVs = 1
        num_D_SV_itrs = 1
        SN_eps = 1e-12
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.which_embedding = functools.partial(layers.SNEmbedding, num_svs=num_D_SVs, num_itrs=num_D_SV_itrs, eps=SN_eps)
        
        self.nc = nc
        self.max_num_nodes = max_num_nodes
        self.max_num_rels = max_num_rels
        
        self.embed_L = self.which_embedding(nlabel, nc)
        self.fuse_l = nn.Sequential(
            nn.Linear(max_num_nodes*(nc), 512),
            nn.ReLU(True)
            )
        self.encoder_d_l = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes, 4, 2, 1), # B,  nc, 64, 64
            nn.ReLU(True),
        )

        self.encoder_e = nn.Sequential(
            nn.Conv2d(self.max_num_nodes, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  8,  8
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  4,  4
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            View((-1, 32*4*4)),
            nn.Linear(512, z_dim*2),
        )
        self.decoder_d = nn.Sequential(
            nn.Linear(z_dim, 256),              # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, 32*4*4),             # B, 32, 4, 4
            nn.ReLU(True),
            View((-1, 32, 4, 4)),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes, 4, 2, 1), # B,  32, 64, 64
            nn.ReLU(True),
        )

        self.decoder_e_l = nn.Sequential(
            nn.Conv2d(self.max_num_nodes, 32, 4, 2, 1),  # B,  32, 32, 32  
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),  # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),

        )
        self.disentangle_1 = nn.Conv2d(32, 151, 4, 2, 1)   # B,  1364,  4,  4
        # self.disentangle_2 = nn.Conv2d(32, 867, 4, 2, 1)  # B,  867,  4,  4
        self.weight_init()
        self.optim = optim.Adam(params=self.parameters(), lr=self.lr,
                                    betas=(self.beta1, self.beta2), weight_decay=1e-5)
    
    def weight_init(self):
        for module in self._modules:
            if (isinstance(self._modules[module], nn.Sequential)):
               for m in self._modules[module]:
                   if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear) or isinstance(self._modules[module], nn.ConvTranspose2d)):
                        # init.xavier_uniform_(m.weight)
                        kaiming_init(m)
            if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear)):
                # init.xavier_uniform_(self._modules[module].weight) 
                init.kaiming_normal(self._modules[module].weight)
                # init.normal_(self._modules[module].weight, 0, 0.02)
            elif isinstance(self._modules[module], (nn.BatchNorm1d, nn.BatchNorm2d)):
                self._modules[module].weight.data.fill_(1)
                if self._modules[module].bias is not None:
                    self._modules[module].bias.data.fill_(0)
    def forward(self, x):
        
        # (C_L, C_R, C_P, index)
        L = x

        L_embed = self.embed_L(L)
        batchsize = L_embed.shape[0]

        output_l = self.fuse_l(L_embed.view(batchsize, -1))

        # forward
        K_c = self.encoder_d_l(output_l.view(-1, 32, 4, 4)) 

        distributions = self.encoder_e(K_c)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)

        K_c_ = self.decoder_d(z)
        x_l = self.decoder_e_l(K_c_[:, :self.max_num_nodes,:,:])
        L_logprob = self.disentangle_1(x_l).view(-1, 64, 151)
        
        return L_logprob, mu, logvar, K_c, K_c_, z
    def decoder_forward(self, K):
        distributions = self.encoder_e(K)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        
        x_l = self.decoder_e_l(K[:, :self.max_num_nodes,:,:])
        L_logprob =  self.disentangle_1(x_l).view(-1, 64, 151)
        return L_logprob, mu, logvar
        
class BetaVAE_G_R(BetaVAE_B):
    """To model the graph label information
    """
    def __init__(self, z_dim=10, nc=10, lr=1e-3 , beta1=0.9, beta2=0.999, max_num_nodes=64, max_num_rels=272, nlabel=151, nattr=201, npred=51):
        super(BetaVAE_G_R, self).__init__()
        # the number of the channel?
        self.nc = nc
        self.z_dim = z_dim
        num_D_SVs = 1
        num_D_SV_itrs = 1
        SN_eps = 1e-12
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.which_embedding = functools.partial(layers.SNEmbedding, num_svs=num_D_SVs, num_itrs=num_D_SV_itrs, eps=SN_eps)
        
        self.nc = nc
        self.max_num_nodes = max_num_nodes
        self.max_num_rels = max_num_rels
        
        self.embed_R = self.which_embedding(nattr, nc)
        self.fuse_r = nn.Sequential(
            nn.Linear(max_num_nodes*(nc)*(nc), 512),
            nn.ReLU(True)
            )
        self.encoder_d_r = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes, 4, 2, 1), # B,  nc, 64, 64
            nn.ReLU(True),
        )
        
        self.encoder_e = nn.Sequential(
            nn.Conv2d(self.max_num_nodes, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  8,  8
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  4,  4
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            View((-1, 32*4*4)),
            nn.Linear(512, z_dim*2),
        )
        self.decoder_d = nn.Sequential(
            nn.Linear(z_dim, 256),              # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, 32*4*4),             # B, 32, 4, 4
            nn.ReLU(True),
            View((-1, 32, 4, 4)),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_nodes, 4, 2, 1), # B,  32, 64, 64
            nn.ReLU(True),
        )
        self.decoder_e_r = nn.Sequential(
            nn.Conv2d(self.max_num_nodes, 32, 4, 2, 1),  # B,  32, 32, 32  
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),  # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
        )
        self.disentangle_1 = nn.Conv2d(32, nattr, 4, 2, 1)   # B,  1364,  4,  4
        # self.disentangle_2 = nn.Conv2d(32, 867, 4, 2, 1)  # B,  867,  4,  4
        self.optim = optim.Adam(params=self.parameters(), lr=self.lr,
                                    betas=(self.beta1, self.beta2), weight_decay=1e-5)
        self.weight_init()
    
    def weight_init(self):
        for module in self._modules:
            if (isinstance(self._modules[module], nn.Sequential)):
               for m in self._modules[module]:
                   if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear) or isinstance(self._modules[module], nn.ConvTranspose2d)):
                        # init.xavier_uniform_(m.weight)
                        kaiming_init(m)
            if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear)):
                # init.xavier_uniform_(self._modules[module].weight) 
                init.kaiming_normal(self._modules[module].weight)
                # init.normal_(self._modules[module].weight, 0, 0.02)
            elif isinstance(self._modules[module], (nn.BatchNorm1d, nn.BatchNorm2d)):
                self._modules[module].weight.data.fill_(1)
                if self._modules[module].bias is not None:
                    self._modules[module].bias.data.fill_(0)
    def forward(self, x):
        
        # (C_L, C_R, C_P, index)
        R = x
        R_embed = self.embed_R(R)
        batchsize = R_embed.shape[0]

        output_r = self.fuse_r(R_embed.view(batchsize, -1))

        # forward
        K_c = self.encoder_d_r(output_r.view(-1, 32, 4, 4)) 

        distributions = self.encoder_e(K_c)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)

        K_c_ = self.decoder_d(z)
        x_r = self.decoder_e_r(K_c_[:, :self.max_num_nodes,:,:])
        R_logprob = self.disentangle_1(x_r).view(-1, 64, 201)
        
        return R_logprob, mu, logvar, K_c, K_c_, z
    def decoder_forward(self, K):
        distributions = self.encoder_e(K)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        
        x_r = self.decoder_e_r(K[:, :self.max_num_nodes,:,:])
        R_logprob =  self.disentangle_1(x_r).view(-1, 64, 201)
        return R_logprob, mu, logvar

class BetaVAE_G_P(BetaVAE_B):
    """To model the graph label information
    """
    def __init__(self, z_dim=10, nc=10, lr=1e-5, beta1=0.9, beta2=0.99, max_num_nodes=64, max_num_rels=272, nlabel=151, nattr=201, npred=51):
        super(BetaVAE_G_P, self).__init__()
        # the number of the channel?
        self.nc = nc
        self.z_dim = z_dim
        num_D_SVs = 1
        num_D_SV_itrs = 1
        SN_eps = 1e-12
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.which_embedding = functools.partial(layers.SNEmbedding, num_svs=num_D_SVs, num_itrs=num_D_SV_itrs, eps=SN_eps)
        
        self.nc = nc
        self.max_num_nodes = max_num_nodes
        self.max_num_rels = max_num_rels
        self.npred = npred
        self.embed_P = self.which_embedding(npred, nc)
        self.fuse_p = nn.Sequential(
            nn.Linear(max_num_rels*(nc), 512),
            nn.ReLU(True)
            )
        self.encoder_d_p = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_rels, 4, 2, 1), # B,  nc, 64, 64
            nn.ReLU(True),
        )
        
        self.encoder_e = nn.Sequential(
            nn.Conv2d(self.max_num_rels, 32, 4, 2, 1),          # B,  32, 32, 32
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32, 16, 16
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  8,  8
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 32, 4, 2, 1),          # B,  32,  4,  4
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            View((-1, 32*4*4)),
            nn.Linear(512, z_dim*2),
        )
        self.decoder_d = nn.Sequential(
            nn.Linear(z_dim, 256),              # B, 256
            nn.ReLU(True),
            nn.Linear(256, 256),                 # B, 256
            nn.ReLU(True),
            nn.Linear(256, 32*4*4),             # B, 32, 4, 4
            nn.ReLU(True),
            View((-1, 32, 4, 4)),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32,  8,  8
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 16, 16
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 32, 4, 2, 1), # B,  32, 32, 32
            nn.ReLU(True),
            nn.ConvTranspose2d(32, self.max_num_rels, 4, 2, 1), # B,  32, 64, 64
            nn.ReLU(True),
        )
        self.decoder_e_p = nn.Sequential(
            nn.Conv2d(self.max_num_rels, 32, 4, 2, 1),  # B,  32, 32, 32  
            nn.BatchNorm2d(32),
            nn.ReLU(True),

        )
        self.disentangle_1 = nn.Conv2d(32, npred, 4, 2, (1,2))   # B,  1364,  4,  4
        self.optim = optim.Adam(params=self.parameters(), lr=self.lr,
                                    betas=(self.beta1, self.beta2), weight_decay=1e-5)
        self.weight_init()
    
    def weight_init(self):
        for module in self._modules:
            if (isinstance(self._modules[module], nn.Sequential)):
               for m in self._modules[module]:
                   if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear) or isinstance(self._modules[module], nn.ConvTranspose2d)):
                        # init.xavier_uniform_(m.weight)
                        kaiming_init(m)
            if (isinstance(self._modules[module], nn.Embedding) or isinstance(self._modules[module], nn.Conv2d) or isinstance(self._modules[module], nn.Linear)):
                # init.xavier_uniform_(self._modules[module].weight) 
                init.kaiming_normal(self._modules[module].weight)
                # init.normal_(self._modules[module].weight, 0, 0.02)
            elif isinstance(self._modules[module], (nn.BatchNorm1d, nn.BatchNorm2d)):
                self._modules[module].weight.data.fill_(1)
                if self._modules[module].bias is not None:
                    self._modules[module].bias.data.fill_(0)
    def forward(self, x):
        
        # (C_L, C_R, C_P, index)
        P = x
        
        P_embed = self.embed_P(P)
        batchsize = P_embed.shape[0]
        output_p = self.fuse_p(P_embed.view(batchsize, -1))

        # forward
        K_c = self.encoder_d_p(output_p.view(-1, 32, 4, 4)) 

        distributions = self.encoder_e(K_c)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        z = reparametrize(mu, logvar)

        K_c_ = self.decoder_d(z)
        x_p = self.decoder_e_p(K_c_[:, :self.max_num_rels,:,:])

        P_logprob =  self.disentangle_1(x_p).view(-1, self.max_num_rels, self.npred)
        
        return P_logprob, mu, logvar, K_c, K_c_, z
    
    def decoder_forward(self, K):
        distributions = self.encoder_e(K)
        mu = distributions[:, :self.z_dim]
        logvar = distributions[:, self.z_dim:]
        
        x_p = self.decoder_e_p(K[:, :self.max_num_rels,:,:])
        P_logprob =  self.disentangle_1(x_p).view(-1, self.max_num_rels, self.npred)
        return P_logprob, mu, logvar

def kaiming_init(m):
    if isinstance(m, (nn.Linear, nn.Conv2d, nn.Embedding, nn.ConvTranspose2d)):
        init.kaiming_normal(m.weight)
        if m.bias is not None:
            m.bias.data.fill_(0)
    elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d)):
        m.weight.data.fill_(1)
        if m.bias is not None:
            m.bias.data.fill_(0)



def normal_init(m, mean, std):
    if isinstance(m, (nn.Linear, nn.Conv2d)):
        m.weight.data.normal_(mean, std)
        if m.bias.data is not None:
            m.bias.data.zero_()
    elif isinstance(m, (nn.BatchNorm2d, nn.BatchNorm1d)):
        m.weight.data.fill_(1)
        if m.bias.data is not None:
            m.bias.data.zero_()


if __name__ == '__main__':
    pass
