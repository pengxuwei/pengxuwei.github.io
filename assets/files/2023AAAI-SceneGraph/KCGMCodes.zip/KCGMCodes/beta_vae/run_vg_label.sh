#! /bin/sh

CUDA_VISIBLE_DEVICES=1 python main.py --dataset vg --seed 101 --lr 1e-4 --beta1 0.9 --beta2 0.999 \
    --objective B --model G_L --batch_size 64 --z_dim 10 --max_iter 1.5e6 \
    --C_stop_iter 1e5 --C_max 10 --gamma 151 --viz_name vg_B_gamma151_z10label \
