"""dataset.py"""

import os
import numpy as np

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision.datasets import ImageFolder
from torchvision import transforms
import json
import h5py
from tqdm import tqdm
import networkx as nx

def is_power_of_2(num):
    return ((num & (num - 1)) == 0) and num != 0


class CustomImageFolder(ImageFolder):
    def __init__(self, root, transform=None):
        super(CustomImageFolder, self).__init__(root, transform)

    def __getitem__(self, index):
        path = self.imgs[index][0]
        img = self.loader(path)
        if self.transform is not None:
            img = self.transform(img)

        return img


class CustomTensorDataset(Dataset):
    def __init__(self, data_tensor):
        self.data_tensor = data_tensor

    def __getitem__(self, index):
        return self.data_tensor[index]

    def __len__(self):
        return self.data_tensor.size(0)

class CustomGraphTensorDataset(Dataset):
    def __init__(self, data):
        self.graphs = data
        self.K = data[3]
        self.K_ = data[4]+2
        self.K_P = data[-1]
    def __getitem__(self, index):
        C_L = self.graphs[5][index]
        C_R = self.graphs[6][index]
        C_P = self.graphs[7][index]
        num_edges = C_P.shape[1]
        num_nodes = C_L.shape[1]
        C_L_ = torch.zeros((self.K_)).long()
        C_R_ = torch.zeros((10, self.K_)).long()
        C_P_ = torch.zeros((self.K_P)).long()

        C_L_[:num_nodes] = torch.LongTensor(C_L)
        C_R_[:, :num_nodes] = torch.LongTensor(C_R)
        C_P_[:num_edges] = torch.LongTensor(C_P)
        return C_L_, C_R_, C_P_
    def __len__(self):
        return len(self.graphs[0])
def return_data(args):
    name = args.dataset
    dset_dir = args.dset_dir
    batch_size = args.batch_size
    num_workers = args.num_workers
    image_size = args.image_size
    assert image_size == 64, 'currently only image size of 64 is supported'

    if name.lower() == '3dchairs':
        root = os.path.join(dset_dir, '3DChairs')
        transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),])
        train_kwargs = {'root':root, 'transform':transform}
        dset = CustomImageFolder

    elif name.lower() == 'celeba':
        root = os.path.join(dset_dir, 'CelebA')
        transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),])
        train_kwargs = {'root':root, 'transform':transform}
        dset = CustomImageFolder

    elif name.lower() == 'dsprites':
        root = os.path.join(dset_dir, 'dsprites-dataset/dsprites_ndarray_co1sh3sc6or40x32y32_64x64.npz')
        if not os.path.exists(root):
            import subprocess
            print('Now download dsprites-dataset')
            subprocess.call(['./download_dsprites.sh'])
            print('Finished')
        data = np.load(root, encoding='bytes')
        data = torch.from_numpy(data['imgs']).unsqueeze(1).float()
        train_kwargs = {'data_tensor':data}
        dset = CustomTensorDataset
    elif name.lower() == 'vg':
        root = './datasets/vg'
        split = 'train'
        dict_file = os.path.join(root, 'VG-SGG-dicts-with-attri.json')
        roidb_file = os.path.join(root, 'VG-SGG-with-attri.h5')
        filter_non_overlap = True
        filter_duplicate_rels = True
        num_val_im = 5000
        num_im = -1
        filter_non_overlap = filter_non_overlap and split == 'train'
        filter_duplicate_rels = filter_duplicate_rels and split == 'train'
        ind_to_classes, ind_to_predicates, ind_to_attributes = load_info(dict_file)
        filter_empty_rels = True
        split_mask, gt_boxes, gt_classes, gt_attributes, relationships = load_graphs(
            roidb_file, split, num_im, num_val_im=num_val_im,
            filter_empty_rels=filter_empty_rels,
            filter_non_overlap=filter_non_overlap,
        )

        graphs = load_graph_matrix(gt_classes, gt_attributes, relationships, ind_to_classes, ind_to_attributes, ind_to_predicates)
        
        train_kwargs = {'data': graphs}
        dset = CustomGraphTensorDataset
    else:
        raise NotImplementedError


    train_data = dset(**train_kwargs)
    train_loader = DataLoader(train_data,
                            batch_size=batch_size,
                            shuffle=True,
                            num_workers=num_workers,
                            pin_memory=True,
                            drop_last=True)

    data_loader = train_loader

    return data_loader
def load_graphs(roidb_file, split, num_im, num_val_im, filter_empty_rels, filter_non_overlap):

    """
    Load the file containing the GT boxes and relations, as well as the datasetsplit
    Parameters:
        roidb_file: HDF5
        split: (train, val, or test)
        num_im: Number of images we want
        num_val_im: Number of validation images
        filter_empty_rels: (will be filtered otherwise.)
        filter_non_overlap: If training, filter images that dont overlap.
    Return: 
        image_index: numpy array corresponding to the index of images we're using
        boxes: List where each element is a [num_gt, 4] array of ground 
                truth boxes (x1, y1, x2, y2)
        gt_classes: List where each element is a [num_gt] array of classes
        relationships: List where each element is a [num_r, 3] array of 
                (box_ind_1, box_ind_2, predicate) relationships
    """
    roi_h5 = h5py.File(roidb_file, 'r')
    data_split = roi_h5['split'][:]
    split_flag = 2 if split == 'test' else 0
    split_mask = data_split == split_flag

    # Filter out images without bounding boxes
    split_mask &= roi_h5['img_to_first_box'][:] >= 0
    if filter_empty_rels:
        split_mask &= roi_h5['img_to_first_rel'][:] >= 0

    image_index = np.where(split_mask)[0]
    if num_im > -1:
        image_index = image_index[:num_im]
    if num_val_im > 0:
        if split == 'val':
            image_index = image_index[:num_val_im]
        elif split == 'train':
            image_index = image_index[num_val_im:]


    split_mask = np.zeros_like(data_split).astype(bool)
    split_mask[image_index] = True

    # Get box information
    all_labels = roi_h5['labels'][:, 0]
    all_attributes = roi_h5['attributes'][:, :]

    im_to_first_box = roi_h5['img_to_first_box'][split_mask]
    im_to_last_box = roi_h5['img_to_last_box'][split_mask]
    im_to_first_rel = roi_h5['img_to_first_rel'][split_mask]
    im_to_last_rel = roi_h5['img_to_last_rel'][split_mask]

    # load relation labels
    _relations = roi_h5['relationships'][:]
    _relation_predicates = roi_h5['predicates'][:, 0]
    assert (im_to_first_rel.shape[0] == im_to_last_rel.shape[0])
    assert (_relations.shape[0] == _relation_predicates.shape[0])  # sanity   check

    # Get everything by image.
    boxes = []
    gt_classes = []
    gt_attributes = []
    relationships = []
    for i in range(len(image_index)):
        i_obj_start = im_to_first_box[i]
        i_obj_end = im_to_last_box[i]
        i_rel_start = im_to_first_rel[i]
        i_rel_end = im_to_last_rel[i]

        gt_classes_i = all_labels[i_obj_start : i_obj_end + 1]
        gt_attributes_i = all_attributes[i_obj_start : i_obj_end + 1, :]

        if i_rel_start >= 0:
            predicates = _relation_predicates[i_rel_start : i_rel_end + 1]
            obj_idx = _relations[i_rel_start : i_rel_end + 1] - i_obj_start # rangeis [0, num_box)
            assert np.all(obj_idx >= 0)
            rels = np.column_stack((obj_idx, predicates)) # (num_rel, 3),representing sub, obj, and pred
        else:
            assert not filter_empty_rels
            rels = np.zeros((0, 3), dtype=np.int32)
        gt_classes.append(gt_classes_i)
        gt_attributes.append(gt_attributes_i)
        relationships.append(rels)

    return split_mask, None, gt_classes, gt_attributes, relationships
def load_image_filenames(img_dir, image_file):
    """
    Loads the image filenames from visual genome from the JSON file that  containsthem.
    This matches the preprocessing in scene-graph-TF-release/ data_toolsvg_to_imdb.py.
    Parameters:
        image_file: JSON file. Elements contain the param "image_id".
        img_dir: directory where the VisualGenome images are located
    Return: 
        List of filenames corresponding to the good images
    """
    with open(image_file, 'r') as f:
        im_data = json.load(f)

    corrupted_ims = ['1592.jpg', '1722.jpg', '4616.jpg', '4617.jpg']
    fns = []
    img_info = []
    for i, img in enumerate(im_data):
        basename = '{}.jpg'.format(img['image_id'])
        if basename in corrupted_ims:
            continue

        filename = os.path.join(img_dir, basename)
        if os.path.exists(filename):
            fns.append(filename)
            img_info.append(img)
    assert len(fns) == 108073
    assert len(img_info) == 108073
    return fns, img_info        

def load_info(dict_file, add_bg=True):
    """
    Loads the file containing the visual genome label meanings
    """
    info = json.load(open(dict_file, 'r'))
    if add_bg:
        info['label_to_idx']['__background__'] = 0
        info['predicate_to_idx']['__background__'] = 0
        info['attribute_to_idx']['__background__'] = 0

    class_to_ind = info['label_to_idx']
    predicate_to_ind = info['predicate_to_idx']
    attribute_to_ind = info['attribute_to_idx']
    ind_to_classes = sorted(class_to_ind, key=lambda k: class_to_ind[k])
    ind_to_predicates = sorted(predicate_to_ind, key=lambda k: predicate_to_ind[k])
    ind_to_attributes = sorted(attribute_to_ind, key=lambda k: attribute_to_ind[k])

    return ind_to_classes, ind_to_predicates, ind_to_attributes

def custom_collate_fn(batch):
    """
    Collate function that batches graphs of varying sizes together into the
    same mini-batch, by padding embeddings / adjacency matrices with zeros.
    Masks are tracked by returning |V| as an extra dataset.
    """
    
    batch_size = len(batch)
    # embed_size = len(batch[0][2][0])
    max_n_nodes = max([len(a) for a, n, l, c, c_r, ii in batch])
    node_number = len(batch[0][0])
    label_number = batch[0][3][0].shape[0]
    attribute_number = batch[0][3][1].shape[0]
    max_relation_number = batch[0][4]
    relation_number = batch[0][3][2].shape[0]
    tgt_device = batch[0][1].device
    C_L = torch.zeros(batch_size, label_number, max_n_nodes).to(tgt_device)
    C_R = torch.zeros(batch_size, attribute_number, max_n_nodes).to(tgt_device)
    C_P = torch.zeros(batch_size, relation_number, max_relation_number).to(tgt_device)
    index = []
    for i, (a, n, l, c, c_r, ii) in enumerate(batch):
        n_nodes = len(a)
        n_edges = c[2].shape[1]
        C_L[i, :, :n_nodes] = torch.from_numpy(c[0])
        C_R[i, :, :n_nodes] = torch.from_numpy(c[1])
        C_P[i, :, :n_edges] = torch.from_numpy(c[2])

        index.append(ii)
    return (C_L, C_R, C_P)

def load_graph_matrix(classes, attributes, relationships, classes_dict, attributes_dict, relationships_dict):
    graph_data = []
    max_nodes = 0
    min_nodes = 1000
    classlabel_data = []
    attribute_data = []
    relationtype_data = []
    max_relations = 0
    for idx, edges in tqdm(enumerate(relationships)):
        G = nx.Graph()
        # nodes are the boxes
        # label and attribute are both attributes of the node
        # relationships are the edges
        assert len(classes[idx]) == len(attributes[idx])
        L = np.zeros((1, len(classes[idx])))
        R = np.zeros((10, len(classes[idx])))
        P = np.zeros((1, len(edges)))

        for i, nd in enumerate(classes[idx]):
            G.add_node(i)
            L[0, i] = nd
            # at most have 10 attributes
            attr = attributes[idx][i]
            
            R[:, i] = attr
        if len(classes[idx]) > max_nodes:
            max_nodes = len(classes[idx])
        if len(classes[idx]) < min_nodes:
            min_nodes = len(classes[idx])
        if len(edges) > max_relations:
            max_relations = len(edges)
        for i, rel in enumerate(edges):
            G.add_edge(rel[0],rel[1])
      
            P[0,i] = rel[2]
        graph_data.append(G)
        classlabel_data.append(L)
        attribute_data.append(R)
        relationtype_data.append(P)

    A = [nx.to_numpy_array(g) for g in graph_data]
    V = [len(a) for a in A]
    L = classlabel_data
    R = attribute_data
    P = relationtype_data
    print('%'*20)
    print('the max number of nodes: ' + str(max_nodes))
    print('%'*20)
    print('the min number of nodes: ' + str(min_nodes))
    print('%'*20)
    print('the max number of relationships: ' + str(max_relations))
    print('%'*20)
    K = min_nodes
    K_ = max_nodes
    K_P = max_relations
    # K = 2

    # C = (L, R, P)

    return np.array(V), np.array(A), None, K, K_, L, R, P, K_P
if __name__ == '__main__':
    transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.ToTensor(),])

    dset = CustomImageFolder('./CelebAMask-HQ', transform)
    loader = DataLoader(dset,
                       batch_size=32,
                       shuffle=True,
                       num_workers=1,
                       pin_memory=False,
                       drop_last=True)

    images1 = iter(loader).next()
    import ipdb; ipdb.set_trace()
