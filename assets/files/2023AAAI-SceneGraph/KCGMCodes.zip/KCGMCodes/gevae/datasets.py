import torch
from collections import defaultdict
from torch.utils.data import Dataset
from torch.utils.data.sampler import Sampler, SequentialSampler


def custom_collate_fn(batch):
    """
    Collate function that batches graphs of varying sizes together into the
    same mini-batch, by padding embeddings / adjacency matrices with zeros.
    Masks are tracked by returning |V| as an extra dataset.
    """
    batch_size = len(batch)
    embed_size = len(batch[3][2][0])
    max_n_nodes = max([len(l) for a, n, l, c_l, c_r, c_p, np, ii in batch])
    # for x in batch[0]:
    #     print(x.shape)
    # print(C_L.shape)
    # node_number = len(batch[0][0])
    # label_number = batch[0][3].shape[0]
    attribute_number = batch[0][4].shape[0]
    max_relation_number = batch[0][-2]
    # relation_number = batch[0][5].shape[0]
    # tgt_device = batch[0][0]
    L = torch.zeros(batch_size, max_n_nodes, embed_size)
    A = torch.zeros(batch_size, max_n_nodes, max_n_nodes)
    V = torch.zeros(batch_size, dtype = torch.float)
    C_L = torch.zeros(batch_size, max_n_nodes).long()
    C_R = torch.zeros(batch_size, attribute_number, max_n_nodes).long()
    C_P = torch.zeros(batch_size, max_relation_number).long()
    # nodes = torch.zeros(batch_size, node_number, dtype = torch.long).to(tgt_device)
    index = []
    for i, (a, n, l, c_l, c_r, c_p, _, ii) in enumerate(batch):
        n_nodes = len(l)

        # print(n_nodes)
        n_edges = c_p.shape[0]
        V[i] = float(n_nodes)
        L[i, :n_nodes, :] = l
        A[i, :n_nodes, :n_nodes] = a
        C_L[i, :n_nodes] = c_l
        C_R[i, :, :n_nodes] = c_r
        
        # assert c_p.shape[0] == relation_number
        C_P[i, :n_edges] = c_p

        # nodes[i] = n
        index.append(ii)
    return (L, A, V, C_L, C_R, C_P, index)


class CustomBatchSampler(Sampler):
    """
    Custom batch sampler that loads the dataset sequentially, but emits a new
    batch each time a graph of different shape is encountered. Results in
    batch sizes that are not always even.
    """
    def __init__(self, dataset, batch_size):
        self.dataset = dataset
        self.batch_size = batch_size
    def __iter__(self):
        batch = []
        for idx in range(len(self.dataset)):
            batch.append(idx)
            if len(batch) == self.batch_size:
                yield batch
                batch = []
            if idx + 1 < len(self.dataset) and \
               len(self.dataset[idx + 1][0]) != len(self.dataset[idx][0]):
                yield batch
                batch = []
        if len(batch) > 0:
            yield batch
    def __len__(self):
        raise ValueError("Not implemented.")


class GraphDataset(Dataset):

    def __init__(self, L, A, device):
        self.L = L
        self.A = A
        self.device =  device

    def __getitem__(self, index):
        L = torch.tensor(self.L[index], dtype = torch.float)
        A = torch.tensor(self.A[index], dtype = torch.float)
        return L.to(self.device), A.to(self.device)

    def __len__(self):
        return len(self.L)



