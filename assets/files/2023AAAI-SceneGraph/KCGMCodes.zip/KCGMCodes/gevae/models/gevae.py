import math
import numpy as np
import scipy as sp
import scipy.linalg
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
from torch.distributions import *
from gevae.modules.attn import *
from gevae.modules.splines import unconstrained_RQS
from gevae.modules.mlp import MLP
from gevae.models.ep import EdgePredictor
from gevae.utils import *
from torch.optim import Adam, SGD
from torch.optim.lr_scheduler import CosineAnnealingLR

class ActNorm(nn.Module):
    """
    ActNorm layer.
    """
    def __init__(self, dim, device):
        super().__init__()
        self.dim = dim
        self.device = device
        self.mu = nn.Parameter(torch.zeros(1, 1, dim,
            dtype = torch.float, device = self.device))
        self.log_sigma = nn.Parameter(torch.zeros(1, 1, dim,
            dtype = torch.float, device = self.device))
        self.initialized = False

    def forward(self, x, v):
        z = x * torch.exp(self.log_sigma) + self.mu
        log_det = torch.sum(self.log_sigma).repeat(x.shape[0]) * v
        return z, log_det

    def backward(self, z, v):
        x = (z - self.mu) / torch.exp(self.log_sigma)
        log_det = -torch.sum(self.log_sigma).repeat(z.shape[0]) * v
        return x, log_det


class OneByOneConv(nn.Module):
    """
    Invertible 1x1 convolution.
    [Kingma and Dhariwal, 2018.]
    """
    def __init__(self, dim, device):
        super().__init__()
        self.dim = dim
        self.device = device
        W, _ = sp.linalg.qr(np.random.randn(dim, dim))
        W = torch.tensor(W, dtype=torch.float, device = device)
        self.W = nn.Parameter(W)
        self.W_inv = None

    def forward(self, x, v):
        z = x @ self.W
        log_det = torch.slogdet(self.W)[1].repeat(x.shape[0]) * v
        return z, log_det

    def backward(self, z, v):
        if self.W_inv is None:
            self.W_inv = torch.inverse(self.W)
        self.W_inv = self.W_inv.to(z.device)
        assert self.W_inv.device == z.device
        x = z @ self.W_inv

        log_det = -torch.slogdet(self.W)[1].repeat(z.shape[0]) * v
        return x, log_det


class NSFLayer(nn.Module):
    """
    Neural spline flow, coupling layer.
    """
    def __init__(self, embedding_dim, device,
                 K = 128, B = 3, hidden_dim = 64, base_network = MLP):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.device = device
        self.K = K
        self.B = B
        self.f1 = ISABStack(4, embedding_dim // 2, hidden_dim, 1, 16, device=device)
        self.f2 = ISABStack(4, embedding_dim // 2, hidden_dim, 1, 16, device=device)
        self.base_network = base_network(
            hidden_dim, (3 * K - 1) * embedding_dim // 2, hidden_dim, device)
        self.conv = OneByOneConv(embedding_dim, device)
        self.actnorm = ActNorm(embedding_dim, device)

    def forward(self, x, v):
        batch_size, max_n_nodes = x.shape[0], x.shape[1]
        mask = construct_embedding_mask(v, max_n_nodes=max_n_nodes)
        x, log_det = self.actnorm(x, v)
        x, ld = self.conv(x, v)
        log_det += ld
        lower = x[:, :, :self.embedding_dim // 2]
        upper = x[:, :, self.embedding_dim // 2:]
        out = self.base_network(self.f1(lower, mask.bool())).reshape(
            batch_size, -1, self.embedding_dim // 2, 3 * self.K - 1)
        W, H, D = torch.split(out, self.K, dim = 3)
        W, H = torch.softmax(W, dim = 3), torch.softmax(H, dim = 3)
        W, H = 2 * self.B * W, 2 * self.B * H
        D = F.softplus(D)
        upper, ld = unconstrained_RQS(
            upper, W, H, D, inverse=False, tail_bound=self.B)
        log_det += torch.sum(ld * mask.unsqueeze(2), dim = (1, 2))
        out = self.base_network(self.f2(upper, mask.bool())).reshape(
            batch_size, -1, self.embedding_dim // 2, 3 * self.K - 1)
        W, H, D = torch.split(out, self.K, dim = 3)
        W, H = torch.softmax(W, dim = 3), torch.softmax(H, dim = 3)
        W, H = 2 * self.B * W, 2 * self.B * H
        D = F.softplus(D)
        lower, ld = unconstrained_RQS(
            lower, W, H, D, inverse=False, tail_bound=self.B)
        log_det += torch.sum(ld * mask.unsqueeze(2), dim = (1, 2))
        return torch.cat([lower, upper], dim = 2), log_det

    def backward(self, z, v):
        batch_size, max_n_nodes = z.shape[0], z.shape[1]
        mask = construct_embedding_mask(v, max_n_nodes=max_n_nodes)
        log_det = torch.zeros_like(v)
        lower = z[:, :, :self.embedding_dim // 2]
        upper = z[:, :, self.embedding_dim // 2:]
        out = self.base_network(self.f2(upper, mask.bool())).reshape(
            batch_size, -1, self.embedding_dim // 2,  3 * self.K - 1)
        W, H, D = torch.split(out, self.K, dim = 3)
        W, H = torch.softmax(W, dim = 3), torch.softmax(H, dim = 3)
        W, H = 2 * self.B * W, 2 * self.B * H
        D = F.softplus(D)
        lower, ld = unconstrained_RQS(
            lower, W, H, D, inverse=True, tail_bound=self.B)
        log_det += torch.sum(ld * mask.unsqueeze(2), dim = (1, 2))
        out = self.base_network(self.f1(lower, mask.bool())).reshape(
            batch_size, -1, self.embedding_dim // 2, 3 * self.K - 1)
        W, H, D = torch.split(out, self.K, dim = 3)
        W, H = torch.softmax(W, dim = 3), torch.softmax(H, dim = 3)
        W, H = 2 * self.B * W, 2 * self.B * H
        D = F.softplus(D)
        upper, ld = unconstrained_RQS(
            upper, W, H, D, inverse=True, tail_bound=self.B)
        log_det += torch.sum(ld *  mask.unsqueeze(2), dim = (1, 2))
        x, ld1 = self.conv.backward(torch.cat([lower, upper], dim = 2), v)
        x, ld2 = self.actnorm.backward(x, v)
        return x, log_det + ld1 + ld2

class GEVAE(nn.Module):
    def __init__(self, embedding_dim, num_flows, noise_lvl, n_knots, device, max_iterations=150000):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.n_knots = n_knots
        self.flows = nn.ModuleList([NSFLayer(embedding_dim, device, n_knots)\
                                    for _ in range(num_flows)])
        
        self.final_actnorm = ActNorm(embedding_dim, device)
        self.noise_lvl = noise_lvl
        self.ep = EdgePredictor(embedding_dim, device)
        self.prior_gen = lambda n_nodes: \
            Normal(torch.zeros(embedding_dim * n_nodes, device = self.device),
                   torch.ones(embedding_dim * n_nodes, device = self.device))
        self.device = device
        self.optim = Adam(params=self.parameters(), lr = 1e-4, weight_decay=1e-5)
        self.scheduler = CosineAnnealingLR(self.optim,  max_iterations)

    def sample_prior(self, n_batch, n_nodes = 20):
        z = self.prior_gen(n_nodes).sample((n_batch,))
        z = z.reshape((n_batch, n_nodes, self.embedding_dim))
        v = torch.ones(n_batch) * n_nodes
        return z, v

    def forward(self, x, a, v):
        """
        Returns
        -------
        z: (batch_size) x (max_n_nodes) x (embedding_size) latent features

        lpn: (batch_size) log probability per node

        lpe: (batch_size) log probability per edge
        """
        batch_size, max_n_nodes = x.shape[0], x.shape[1]
        # print(self.device)
        log_det = torch.zeros(batch_size, device = x.device)
        # self.register_buffer("log_det",  log_det)
        x_distn = Normal(loc = x, scale = self.noise_lvl)
        mask = construct_embedding_mask(v, max_n_nodes=max_n_nodes).unsqueeze(2)
        x = x_distn.rsample()
        rsample_logprob  = torch.sum(x_distn.log_prob(x) * mask, dim = (1, 2))
        rsample_logprob = rsample_logprob # / v / self.embedding_dim
        
        ep_logprob, k_g_e = self.ep.log_prob_per_edge(x, a, v, max_n_nodes=max_n_nodes)
        # self.flows.to(x.device)
        # self.final_actnorm.to(x.device)
        # self.ep.to(x.device)
        for flow in self.flows:
            x, LD = flow.forward(x, v)
            log_det += LD
        x, LD = self.final_actnorm(x, v)
        log_det += LD
        prior = self.prior_gen(max_n_nodes)
        z, prior_logprob = x, prior.log_prob(x.view(batch_size, -1))
        prior_logprob = prior_logprob.reshape((batch_size, max_n_nodes, -1))
        prior_logprob = torch.sum(prior_logprob * mask, dim = (1, 2))
        node_logprob = (prior_logprob + log_det) #/ v / self.embedding_dim
        const = torch.log(torch.tensor(2.0))

        # knowledge output
        z_ = prior.sample((batch_size,))
        z_ = z_.reshape((batch_size, max_n_nodes, self.embedding_dim))
        # v = torch.ones(batch_size) * max_n_nodes
        e_sampled = self.backward(z_, v)
        k_g_d = self.ep.forward(e_sampled, v, max_n_nodes=max_n_nodes)[1]

        return z, (node_logprob - rsample_logprob) / const, ep_logprob / const, k_g_e, k_g_d
    
    def reconstruct_from_k_g(self, k_g, v, z, e, a_sampled):
        batch_size = k_g.shape[0]
        device = k_g.device
        F = k_g @ k_g.transpose(1, 2)
        ber = F * torch.exp(self.ep.scale1) + self.ep.baseline
        a_hat = Bernoulli(logits=ber).probs
        # a_sampled = torch.zeros((batch_size, max_n_nodes, max_n_nodes)).to(device)
        # print(a_sampled.shape)
        for i in range(batch_size):
            # sampled = torch.sign(a_hat[i] - (torch.tril(z[i]) + torch.tril(z[i], diagonal=-1).T))
            # sampled = a_hat[i] - (torch.tril(z[i]) + torch.tril(z[i],diagonal=-1).T)
            sampled = a_hat[i]
            sampled = torch.relu(sampled[i, :v[i].long(), :v[i].long()])
            a_sampled[i,:v[i].long(),:v[i].long()] = sampled
            # e[i,:v[i].long(),:] = compute_unnormalized_laplacian_eigenmaps(sampled)[:,:e.shape[2]]
        return a_sampled, None, v

    def predict_a_from_e(self, X, V):
        return Bernoulli(logits = self.ep.forward(X, V)[0]).probs

    def backward(self, z, v):
        z, _ = self.final_actnorm.backward(z, v)
        for flow in self.flows[::-1]:
            z, _ = flow.backward(z, v)
        return z
def compute_normalized_laplacian_eigenmaps(A, eps=1e-2):
    # A = A+eps
    D = A.sum(1)
    D_mask = D <= 0.0
    D = D + D_mask * eps
    L = torch.diag(D) - A
    L = torch.diag(D ** -0.5) @ L @ torch.diag(D ** -0.5)
    W, E = torch.symeig(L, eigenvectors=True)
    E = E @ torch.diag(torch.sign(E.sum(0)))
    # E = E @ torch.diag(torch.sign(W))
    return E
def compute_unnormalized_laplacian_eigenmaps(A, eps=1e-2):
    
    D = A.sum(1)
    D_mask = D == 0.0
    D = torch.diag(D + D_mask * eps)
    L = D - A
    W, E = torch.symeig(L, eigenvectors=True)
    E = E @ torch.diag(torch.sign(W))
    return E
class WEBD(nn.Module):
    def __init__(self, max_nodes, embedding_dim, z_dim, device='cuda', lr=1e-3, init='N02'):
        super().__init__()
        self.embedding_dim = embedding_dim # K
        self.max_n_nodes = max_nodes
        self.z_dim = z_dim
        self.device = device
        self.lr = lr

        self.encode_layer = nn.Conv2d(self.embedding_dim, 1, 1, 1, 0).to(device)
        self.fc = nn.Conv2d(self.max_n_nodes, self.z_dim, 1, 1, 0).to(device)
        self.optim = SGD(params=self.parameters(), lr=self.lr)
        self.init = init
        self.loss = nn.MSELoss()
        
        self.init_weights()
    
    def forward(self, z_vae, z_gan):
        pad = self.max_n_nodes - z_vae.shape[1]
        z_vae = F.pad(z_vae, (0,0, pad, 0, 0, 0))
        y = self.encode_layer(z_vae.view(z_vae.shape[0], z_vae.shape[2], -1, 1))
        y = self.fc(y.view(y.shape[0], y.shape[2], -1, 1)).view(y.shape[0], -1)
        return y, self.loss(y, z_gan)
    
    def init_weights(self):
        self.param_count = 0
        for module in self.modules():
            if (isinstance(module, nn.Conv2d) 
                or isinstance(module, nn.Linear) 
                or isinstance(module, nn.Embedding)):
                if self.init == 'ortho':
                    init.orthogonal_(module.weight)
                elif self.init == 'N02':
                    init.normal_(module.weight, 0, 0.02)
                elif self.init in ['glorot', 'xavier']:
                    init.xavier_uniform_(module.weight)
                else:
                    print('Init style not recognized...')
                self.param_count += sum([p.data.nelement() for p in module.parameters()])
        print('Param count for G''s initialized parameters: %d' % self.param_count)