import os
import networkx as nx
import numpy as np
import json
from tqdm import tqdm
import h5py
import pdb 

from argparse import ArgumentParser
from tqdm import tqdm
from src.embeddings import compute_unnormalized_laplacian_eigenmaps

BOX_SCALE = 1024

def load_vg_data(split='train'):
    # corrupted = [1592, 1722, 4616, 4617, 1629, 2335, 2482, 2576]
    corrupted_file = 'corrupted_images.json'
    data_path = 'path_to_corruped_graph_id_in_vg_dataset'

    with open(os.path.join(data_path, corrupted_file), 'r') as f:
        corrupted = json.load(f)
    
    # relation file
    # number of the images, the index and the subgraph
    graph_file = 'scene_graphs_n.json'
    with open(os.path.join(data_path, graph_file), 'r') as f:
        graphs = json.load(f)
    
    # number of relation*2 + attributes*1 = the number of edges
    id_to_word = 'dict_id_to_objects.json'
    with open(os.path.join(data_path, id_to_word), 'r') as f:
        object_dict = json.load(f)
    max_nodes = 0
    min_nodes = 10000
    graph_data = []
    count = 0
    roidb_file = os.path.join(data_path,'VG-SGG-with-attri.h5')
    # split = 'train'
    num_im = -1

    split_mask, gt_boxes, gt_classes, gt_attributes, relationships = load_graphs(
            roidb_file, split, num_im, num_val_im=0,
            filter_empty_rels=True,
            filter_non_overlap=True,
        )
    img_dir = os.path.join(data_path, 'VG_100K')
    image_file = os.path.join(data_path, 'image_data.json')

    filenames, img_info = load_image_filenames(img_dir, image_file)
    
    dict_file = os.path.join(data_path, 'VG-SGG-dicts-with-attri.json')
    ind_to_classes, ind_to_predicates, ind_to_attributes = load_info(dict_file)
    # one image one graph
    graph_data = []
    max_nodes = 0
    min_nodes = 1000
    for idx, edges in tqdm(enumerate(relationships)):
        G = nx.Graph()
        # nodes are the boxes
        # label and attribute are both attributes of the node
        # relationships are the edges
        assert len(gt_classes[idx]) == len(gt_attributes[idx])
        for i, nd in enumerate(gt_classes[idx]):
            G.add_node(i)
        if len(gt_classes[idx]) > max_nodes:
            max_nodes = len(gt_classes[idx])
        if len(gt_classes[idx]) < min_nodes:
            min_nodes = len(gt_classes[idx])
        
        for i, rel in enumerate(edges):
            G.add_edge(rel[0],rel[1])

            

        graph_data.append(G)
        
            # pdb.set_trace()
    A = [nx.to_numpy_array(g) for g in graph_data]
    V = [len(a) for a in A]
    print('%'*20)
    print('the max number of nodes: ' + str(max_nodes))
    print('%'*20)
    print('the min number of nodes: ' + str(min_nodes))
    print('%'*20)
    return np.array(V), np.array(A)           

def load_graphs(roidb_file, split, num_im, num_val_im, filter_empty_rels, filter_non_overlap):

    """
    Load the file containing the GT boxes and relations, as well as the datasetsplit
    Parameters:
        roidb_file: HDF5
        split: (train, val, or test)
        num_im: Number of images we want
        num_val_im: Number of validation images
        filter_empty_rels: (will be filtered otherwise.)
        filter_non_overlap: If training, filter images that dont overlap.
    Return: 
        image_index: numpy array corresponding to the index of images we're using
        boxes: List where each element is a [num_gt, 4] array of ground 
                truth boxes (x1, y1, x2, y2)
        gt_classes: List where each element is a [num_gt] array of classes
        relationships: List where each element is a [num_r, 3] array of 
                (box_ind_1, box_ind_2, predicate) relationships
    """
    roi_h5 = h5py.File(roidb_file, 'r')
    data_split = roi_h5['split'][:]
    split_flag = 2 if split == 'test' else 0
    split_mask = data_split == split_flag

    # Filter out images without bounding boxes
    split_mask &= roi_h5['img_to_first_box'][:] >= 0
    if filter_empty_rels:
        split_mask &= roi_h5['img_to_first_rel'][:] >= 0

    image_index = np.where(split_mask)[0]
    if num_im > -1:
        image_index = image_index[:num_im]
    if num_val_im > 0:
        if split == 'val':
            image_index = image_index[:num_val_im]
        elif split == 'train':
            image_index = image_index[num_val_im:]


    split_mask = np.zeros_like(data_split).astype(bool)
    split_mask[image_index] = True

    # Get box information
    all_labels = roi_h5['labels'][:, 0]
    all_attributes = roi_h5['attributes'][:, :]

    im_to_first_box = roi_h5['img_to_first_box'][split_mask]
    im_to_last_box = roi_h5['img_to_last_box'][split_mask]
    im_to_first_rel = roi_h5['img_to_first_rel'][split_mask]
    im_to_last_rel = roi_h5['img_to_last_rel'][split_mask]

    # load relation labels
    _relations = roi_h5['relationships'][:]
    _relation_predicates = roi_h5['predicates'][:, 0]
    assert (im_to_first_rel.shape[0] == im_to_last_rel.shape[0])
    assert (_relations.shape[0] == _relation_predicates.shape[0])  # sanity   check

    # Get everything by image.
    boxes = []
    gt_classes = []
    gt_attributes = []
    relationships = []
    for i in range(len(image_index)):
        i_obj_start = im_to_first_box[i]
        i_obj_end = im_to_last_box[i]
        i_rel_start = im_to_first_rel[i]
        i_rel_end = im_to_last_rel[i]

        # boxes_i = all_boxes[i_obj_start : i_obj_end + 1, :]
        gt_classes_i = all_labels[i_obj_start : i_obj_end + 1]
        gt_attributes_i = all_attributes[i_obj_start : i_obj_end + 1, :]

        if i_rel_start >= 0:
            predicates = _relation_predicates[i_rel_start : i_rel_end + 1]
            obj_idx = _relations[i_rel_start : i_rel_end + 1] - i_obj_start # rangeis [0, num_box)
            assert np.all(obj_idx >= 0)
            rels = np.column_stack((obj_idx, predicates)) # (num_rel, 3),representing sub, obj, and pred
        else:
            assert not filter_empty_rels
            rels = np.zeros((0, 3), dtype=np.int32)

        gt_classes.append(gt_classes_i)
        gt_attributes.append(gt_attributes_i)
        relationships.append(rels)

        # return split_mask, boxes, gt_classes, gt_attributes, relationships
    return split_mask, None, gt_classes, gt_attributes, relationships
def load_image_filenames(img_dir, image_file):
    """
    Loads the image filenames from visual genome from the JSON file that  containsthem.
    This matches the preprocessing in scene-graph-TF-release/ data_toolsvg_to_imdb.py.
    Parameters:
        image_file: JSON file. Elements contain the param "image_id".
        img_dir: directory where the VisualGenome images are located
    Return: 
        List of filenames corresponding to the good images
    """
    with open(image_file, 'r') as f:
        im_data = json.load(f)

    corrupted_ims = ['1592.jpg', '1722.jpg', '4616.jpg', '4617.jpg']
    fns = []
    img_info = []
    for i, img in enumerate(im_data):
        basename = '{}.jpg'.format(img['image_id'])
        if basename in corrupted_ims:
            continue

        filename = os.path.join(img_dir, basename)
        if os.path.exists(filename):
            fns.append(filename)
            img_info.append(img)
    assert len(fns) == 108073
    assert len(img_info) == 108073
    return fns, img_info        

def load_info(dict_file, add_bg=True):
    """
    Loads the file containing the visual genome label meanings
    """
    info = json.load(open(dict_file, 'r'))
    if add_bg:
        info['label_to_idx']['__background__'] = 0
        info['predicate_to_idx']['__background__'] = 0
        info['attribute_to_idx']['__background__'] = 0

    class_to_ind = info['label_to_idx']
    predicate_to_ind = info['predicate_to_idx']
    attribute_to_ind = info['attribute_to_idx']
    ind_to_classes = sorted(class_to_ind, key=lambda k: class_to_ind[k])
    ind_to_predicates = sorted(predicate_to_ind, key=lambda k: predicate_to_ind[k])
    ind_to_attributes = sorted(attribute_to_ind, key=lambda k: attribute_to_ind[k])

    return ind_to_classes, ind_to_predicates, ind_to_attributes
if __name__ == "__main__":
    # split is included in roi.h5 
    argparser = ArgumentParser()
    argparser.add_argument("--train-N", default=880, type=int)
    argparser.add_argument("--seed", default=123, type=int)
    args = argparser.parse_args()
    
    np.random.seed(args.seed)  
    V, A = load_vg_data()
    E = np.array([compute_unnormalized_laplacian_eigenmaps(a) for a in A])      
    K = min([e.shape[1] for e in E])
    # K = 2
    E = np.array([e[:, :K] for e in E])
    np.save("datasets/vg/train_A.npy", A)    
    np.save("datasets/vg/train_E.npy", E)
    np.save("datasets/vg/train_V.npy", V)
    
    V, A = load_vg_data(split='test')
    E = np.array([compute_unnormalized_laplacian_eigenmaps(a) for a in A]) 
    np.save("datasets/vg/test_A.npy", A)
    np.save("datasets/vg/test_E.npy", E)
    np.save("datasets/vg/test_V.npy", V)


    
    
    