#!/bin/bash
python -m pdb make_hdf5.py --dataset VGDataset --batch_size 256 --data_root ~/Projects/KCGN/datasets/vg/VG_100K
python calculate_inception_moments.py --dataset VGDataset --data_root ~/Projects/KCGN/datasets/vg/VG_100K
