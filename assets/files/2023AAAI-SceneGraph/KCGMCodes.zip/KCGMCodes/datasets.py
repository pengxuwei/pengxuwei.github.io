''' Datasets
    This file contains definitions for our CIFAR, ImageFolder, and Visual Genome
'''
import os
import os.path
import sys
from PIL import Image
import numpy as np
from tqdm import tqdm, trange
import json
import h5py
from collections import defaultdict
from maskrcnn_benchmark.structures.bounding_box import BoxList
from maskrcnn_benchmark.structures.boxlist_ops import boxlist_iou
import random 
import networkx as nx
from gevae.embeddings import compute_unnormalized_laplacian_eigenmaps

import torchvision.datasets as dset
import torchvision.transforms as transforms
from torchvision.datasets.utils import download_url, check_integrity
import torch.utils.data as data
from torch.utils.data import DataLoader


IMG_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.ppm', '.bmp', '.pgm']


def is_image_file(filename):
    """Checks if a file is an image.

    Args:
        filename (string): path to a file

    Returns:
        bool: True if the filename ends with a known image extension
    """
    filename_lower = filename.lower()
    return any(filename_lower.endswith(ext) for ext in IMG_EXTENSIONS)


def find_classes(dir):
    classes = [d for d in os.listdir(dir) if os.path.isdir(os.path.join(dir, d))]
    classes.sort()
    class_to_idx = {classes[i]: i for i in range(len(classes))}
    return classes, class_to_idx


def make_dataset(dir, class_to_idx):
  images = []
  dir = os.path.expanduser(dir)
  for target in tqdm(sorted(os.listdir(dir))):
    d = os.path.join(dir, target)
    if not os.path.isdir(d):
      continue

    for root, _, fnames in sorted(os.walk(d)):
      for fname in sorted(fnames):
        if is_image_file(fname):
          path = os.path.join(root, fname)
          item = (path, class_to_idx[target])
          images.append(item)

  return images


def pil_loader(path):
    # open path as file to avoid ResourceWarning (https://github.com/python-pillow/Pillow/issues/835)
  with open(path, 'rb') as f:
    img = Image.open(f)
    return img.convert('RGB')


def accimage_loader(path):
  import accimage
  try:
    return accimage.Image(path)
  except IOError:
    # Potentially a decoding problem, fall back to PIL.Image
    return pil_loader(path)


def default_loader(path):
  from torchvision import get_image_backend
  if get_image_backend() == 'accimage':
    return accimage_loader(path)
  else:
    return pil_loader(path)


class ImageFolder(data.Dataset):
  """A generic data loader where the images are arranged in this way: ::

      root/dogball/xxx.png
      root/dogball/xxy.png
      root/dogball/xxz.png

      root/cat/123.png
      root/cat/nsdf3.png
      root/cat/asd932_.png

  Args:
      root (string): Root directory path.
      transform (callable, optional): A function/transform that  takes in an PIL image
          and returns a transformed version. E.g, ``transforms.RandomCrop``
      target_transform (callable, optional): A function/transform that takes in the
          target and transforms it.
      loader (callable, optional): A function to load an image given its path.

   Attributes:
      classes (list): List of the class names.
      class_to_idx (dict): Dict with items (class_name, class_index).
      imgs (list): List of (image path, class_index) tuples
  """

  def __init__(self, root, transform=None, target_transform=None,
               loader=default_loader, load_in_mem=False, 
               index_filename='imagenet_imgs.npz', **kwargs):
    classes, class_to_idx = find_classes(root)
    # Load pre-computed image directory walk
    if os.path.exists(index_filename):
      print('Loading pre-saved Index file %s...' % index_filename)
      imgs = np.load(index_filename)['imgs']
    # If first time, walk the folder directory and save the 
    # results to a pre-computed file.
    else:
      print('Generating  Index file %s...' % index_filename)
      imgs = make_dataset(root, class_to_idx)
      np.savez_compressed(index_filename, **{'imgs' : imgs})
    if len(imgs) == 0:
      raise(RuntimeError("Found 0 images in subfolders of: " + root + "\n"
                           "Supported image extensions are: " + ",".join(IMG_EXTENSIONS)))

    self.root = root
    self.imgs = imgs
    self.classes = classes
    self.class_to_idx = class_to_idx
    self.transform = transform
    self.target_transform = target_transform
    self.loader = loader
    self.load_in_mem = load_in_mem
    
    if self.load_in_mem:
      print('Loading all images into memory...')
      self.data, self.labels = [], []
      for index in tqdm(range(len(self.imgs))):
        path, target = imgs[index][0], imgs[index][1]
        self.data.append(self.transform(self.loader(path)))
        self.labels.append(target)
          

  def __getitem__(self, index):
    """
    Args:
        index (int): Index

    Returns:
        tuple: (image, target) where target is class_index of the target class.
    """
    if self.load_in_mem:
        img = self.data[index]
        target = self.labels[index]
    else:
      path, target = self.imgs[index]
      img = self.loader(str(path))
      if self.transform is not None:
        img = self.transform(img)
    
    if self.target_transform is not None:
      target = self.target_transform(target)
    
    # print(img.size(), target)
    return img, int(target)

  def __len__(self):
    return len(self.imgs)

  def __repr__(self):
    fmt_str = 'Dataset ' + self.__class__.__name__ + '\n'
    fmt_str += '    Number of datapoints: {}\n'.format(self.__len__())
    fmt_str += '    Root Location: {}\n'.format(self.root)
    tmp = '    Transforms (if any): '
    fmt_str += '{0}{1}\n'.format(tmp, self.transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
    tmp = '    Target Transforms (if any): '
    fmt_str += '{0}{1}'.format(tmp, self.target_transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
    return fmt_str
        

''' ILSVRC_HDF5: A dataset to support I/O from an HDF5 to avoid
    having to load individual images all the time. '''
import h5py as h5
import torch
class ILSVRC_HDF5(data.Dataset):
  def __init__(self, root, transform=None, target_transform=None,
               load_in_mem=False, train=True,download=False, validate_seed=0,
               val_split=0, **kwargs): # last four are dummies
      
    self.root = root
    self.num_imgs = len(h5.File(root, 'r')['labels'])
    
    # self.transform = transform
    self.target_transform = target_transform   
    
    # Set the transform here
    self.transform = transform
    
    # load the entire dataset into memory? 
    self.load_in_mem = load_in_mem
    
    # If loading into memory, do so now
    if self.load_in_mem:
      print('Loading %s into memory...' % root)
      with h5.File(root,'r') as f:
        self.data = f['imgs'][:]
        self.labels = f['labels'][:]

  def __getitem__(self, index):
    """
    Args:
        index (int): Index

    Returns:
        tuple: (image, target) where target is class_index of the target class.
    """
    # If loaded the entire dataset in RAM, get image from memory
    if self.load_in_mem:
      img = self.data[index]
      target = self.labels[index]
    
    # Else load it from disk
    else:
      with h5.File(self.root,'r') as f:
        img = f['imgs'][index]
        target = f['labels'][index]
    
   
    # if self.transform is not None:
        # img = self.transform(img)
    # Apply my own transform
    img = ((torch.from_numpy(img).float() / 255) - 0.5) * 2
    
    if self.target_transform is not None:
      target = self.target_transform(target)
    
    return img, int(target)

  def __len__(self):
      return self.num_imgs
      # return len(self.f['imgs'])

import pickle
class CIFAR10(dset.CIFAR10):

  def __init__(self, root, train=True,
           transform=None, target_transform=None,
           download=True, validate_seed=0,
           val_split=0, load_in_mem=True, **kwargs):
    self.root = os.path.expanduser(root)
    self.transform = transform
    self.target_transform = target_transform
    self.train = train  # training set or test set
    self.val_split = val_split

    if download:
      self.download()

    if not self._check_integrity():
      raise RuntimeError('Dataset not found or corrupted.' +
                           ' You can use download=True to download it')

    # now load the picked numpy arrays    
    self.data = []
    self.labels= []
    for fentry in self.train_list:
      f = fentry[0]
      file = os.path.join(self.root, self.base_folder, f)
      fo = open(file, 'rb')
      if sys.version_info[0] == 2:
        entry = pickle.load(fo)
      else:
        entry = pickle.load(fo, encoding='latin1')
      self.data.append(entry['data'])
      if 'labels' in entry:
        self.labels += entry['labels']
      else:
        self.labels += entry['fine_labels']
      fo.close()
        
    self.data = np.concatenate(self.data)
    # Randomly select indices for validation
    if self.val_split > 0:
      label_indices = [[] for _ in range(max(self.labels)+1)]
      for i,l in enumerate(self.labels):
        label_indices[l] += [i]  
      label_indices = np.asarray(label_indices)
      
      # randomly grab 500 elements of each class
      np.random.seed(validate_seed)
      self.val_indices = []           
      for l_i in label_indices:
        self.val_indices += list(l_i[np.random.choice(len(l_i), int(len(self.data) * val_split) // (max(self.labels) + 1) ,replace=False)])
    
    if self.train=='validate':    
      self.data = self.data[self.val_indices]
      self.labels = list(np.asarray(self.labels)[self.val_indices])
      
      self.data = self.data.reshape((int(50e3 * self.val_split), 3, 32, 32))
      self.data = self.data.transpose((0, 2, 3, 1))  # convert to HWC
    
    elif self.train:
      print(np.shape(self.data))
      if self.val_split > 0:
        self.data = np.delete(self.data,self.val_indices,axis=0)
        self.labels = list(np.delete(np.asarray(self.labels),self.val_indices,axis=0))
          
      self.data = self.data.reshape((int(50e3 * (1.-self.val_split)), 3, 32, 32))
      self.data = self.data.transpose((0, 2, 3, 1))  # convert to HWC
    else:
      f = self.test_list[0][0]
      file = os.path.join(self.root, self.base_folder, f)
      fo = open(file, 'rb')
      if sys.version_info[0] == 2:
        entry = pickle.load(fo)
      else:
        entry = pickle.load(fo, encoding='latin1')
      self.data = entry['data']
      if 'labels' in entry:
        self.labels = entry['labels']
      else:
        self.labels = entry['fine_labels']
      fo.close()
      self.data = self.data.reshape((10000, 3, 32, 32))
      self.data = self.data.transpose((0, 2, 3, 1))  # convert to HWC
      
  def __getitem__(self, index):
    """
    Args:
        index (int): Index
    Returns:
        tuple: (image, target) where target is index of the target class.
    """
    img, target = self.data[index], self.labels[index]

    # doing this so that it is consistent with all other datasets
    # to return a PIL Image
    img = Image.fromarray(img)

    if self.transform is not None:
      img = self.transform(img)

    if self.target_transform is not None:
      target = self.target_transform(target)

    return img, target
      
  def __len__(self):
      return len(self.data)


class CIFAR100(CIFAR10):
    base_folder = 'cifar-100-python'
    url = "http://www.cs.toronto.edu/~kriz/cifar-100-python.tar.gz"
    filename = "cifar-100-python.tar.gz"
    tgz_md5 = 'eb9058c3a382ffc7106e4002c42a8d85'
    train_list = [
        ['train', '16019d7e3df5f24257cddd939b257f8d'],
    ]

    test_list = [
        ['test', 'f0ef6b0ae62326f3e7ffdfab6717acfc'],
    ]
class MSCOCO(data.Dataset):
  def __init__(self, root='/media/pig/Projects/data/ms-coco', transform=None, target_transform=None,
               loader=default_loader, load_in_mem=False, 
               index_filename='annotations/instances_train2017_2.json', **kwargs):
    # imagelist = os.listdir(os.path.join(root,'train2017'))
    imgs = []
    if os.path.exists(os.path.join(root, index_filename)):
      annotations = os.path.join(root, index_filename)
      targets = []

      with open(os.path.join(root, index_filename), 'r') as f:
        labels = json.load(f)
        label_id = labels['category_update']
        for idx, im in enumerate(labels['annotations']):
          imgs.append(os.path.join(root, 'train2017', str(im['image_id']).zfill(12)+'.jpg'))
          targets.append(label_id[str(im['category_id'])])
    self.transform =  transform
    self.root = root
    self.imgs = imgs
    self.targets = targets
    self.load_in_mem = load_in_mem
    self.loader = loader
    self.target_transform = target_transform
    if self.load_in_mem:
      print('Loading all images into memory...')
      self.data, self.labels = [], []
      for index in tqdm(range(len(self.imgs))):
        path, target = imgs[index], targets[index]
        self.data.append(self.transform(self.loader(path)))
        self.labels.append(target)
  def __getitem__(self, index):
    if self.load_in_mem:
      img = self.data[index]
      target = self.labels[index]
    else:
      path = self.imgs[index]
      target = self.targets[index]
      img = self.transform(self.loader(str(path)))
    if self.target_transform is not None:
      target = self.target_transform(target)
    return img, int(target)
  def __len__(self):
    return len(self.imgs)
  
  def __repr__(self):
    fmt_str = 'Dataset ' + self.__class__.__name__ + '\n'
    fmt_str += '    Number of datapoints: {}\n'.format(self.__len__())
    fmt_str += '    Root Location: {}\n'.format(self.root)
    tmp = '    Transforms (if any): '
    fmt_str += '{0}{1}\n'.format(tmp, self.transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
    tmp = '    Target Transforms (if any): '
    fmt_str += '{0}{1}'.format(tmp, self.target_transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
    return fmt_str 


BOX_SCALE = 1024  # Scale at which we have the boxes

class VGDataset(data.Dataset):
  def __init__(self, root, load_in_mem=None, split=None, img_dir=None, roidb_file=None, dict_file=None, image_file=None, transform=None, 
        filter_empty_rels=True, num_im=-1, num_val_im=5000,
        filter_duplicate_rels=True, filter_non_overlap=True, flip_aug=False, custom_eval=False, custom_path='', mode='generative', loader = default_loader):
    """
    Torch dataset for VisualGenome
    Parameters:
      split: Must be train, test, or val
      img_dir: folder containing all vg images
      roidb_file:  HDF5 containing the GT boxes, classes, and relationships
      dict_file: JSON Contains mapping of classes/relationships to words
      image_file: HDF5 containing image filenames
      filter_empty_rels: True if we filter out images without relationships between
            boxes. One might want to set this to false if training a detector.
      filter_duplicate_rels: Whenever we see a duplicate relationship we'll sample instead
      num_im: Number of images in the entire dataset. -1 for all images.
      num_val_im: Number of images in the validation set (must be less than num_im
      unless num_im is -1.)
    """
    # for debug
    # num_im = 10000
    # num_val_im = 4

    assert split in {'train', 'val', 'test'}
    
    self.flip_aug = flip_aug
    self.split = split
    self.img_dir = img_dir
    self.dict_file = dict_file
    self.roidb_file = roidb_file
    self.image_file = image_file
    self.filter_non_overlap = filter_non_overlap and self.split == 'train'
    self.filter_duplicate_rels = filter_duplicate_rels and self.split == 'train'
    self.transforms = transform
    self.mode = mode
    self.ind_to_classes, self.ind_to_predicates, self.ind_to_attributes = load_info(dict_file) # contiguous 151, 51 containing __background__
    self.categories = {i : self.ind_to_classes[i] for i in range(len(self.ind_to_classes))}
    self.loader = default_loader
    self.custom_eval = custom_eval
    if self.custom_eval:
        self.get_custom_imgs(custom_path)
    else:
      self.split_mask, self.gt_boxes, self.gt_classes, self.gt_attributes, self.relationships = load_graphs(
          self.roidb_file, self.split, num_im, num_val_im=num_val_im,
          filter_empty_rels=filter_empty_rels,
          filter_non_overlap=self.filter_non_overlap,
      )

      self.filenames, self.img_info = load_image_filenames(img_dir, image_file) # length equals to split_mask
      self.filenames = [self.filenames[i] for i in np.where(self.split_mask)[0]]
      self.img_info = [self.img_info[i] for i in np.where(self.split_mask)[0]]
    aa = 1

  def __getitem__(self, index):
    #if self.split == 'train':
    #    while(random.random() > self.img_info[index]['anti_prop']):
    #        index = int(random.random() * len(self.filenames))
    if self.custom_eval:
      img = Image.open(self.custom_files[index]).convert("RGB")
      target = torch.LongTensor([-1])
      if self.transforms is not None:
        img, target = self.transforms(img, target)
      return img, target, index
        
    # img = Image.open(self.filenames[index]).convert("RGB")
    img = self.loader(self.filenames[index])
    # if img.size[0] != self.img_info[index]['width'] or img.size[1] != self.img_info[index]['height']:
    #   print('='*20, ' ERROR index ', str(index), ' ', str(img.size), ' ', str(self.img_info[index]['width']), ' ', str(self.img_info[index]['height']), ' ', '='*20)

    # flip_img = (random.random() > 0.5) and self.flip_aug and (self.split == 'train')
        
    # target = self.get_groundtruth(index, flip_img)

    # if flip_img:
    #   img = img.transpose(method=Image.FLIP_LEFT_RIGHT)

    if self.transforms is not None:
      if self.mode=='generative':
        img = self.transforms(img)
        # img = self.transforms[1](img)
        for i in self.gt_classes[index]:
          if i == 0:
           continue
          else:
            target = int(i-1)
        
        
      elif self.mode == 'detection':
        img, target = self.transforms(img, target)
    
    return img, target
      # img = self.transforms(img)

  def get_statistics(self):
    fg_matrix, bg_matrix = get_VG_statistics(img_dir=self.img_dir, roidb_file=self.roidb_file, dict_file=self.dict_file,
                      image_file=self.image_file, must_overlap=True)
    eps = 1e-3
    bg_matrix += 1
    fg_matrix[:, :, 0] = bg_matrix
    pred_dist = np.log(fg_matrix / fg_matrix.sum(2)[:, :, None] + eps)

    result = {
      'fg_matrix': torch.from_numpy(fg_matrix),
      'pred_dist': torch.from_numpy(pred_dist).float(),
      'obj_classes': self.ind_to_classes,
      'rel_classes': self.ind_to_predicates,
      'att_classes': self.ind_to_attributes,
    }
    return result

  def get_custom_imgs(self, path):
    self.custom_files = []
    self.img_info = []
    for file_name in os.listdir(path):
      self.custom_files.append(os.path.join(path, file_name))
      img = Image.open(os.path.join(path, file_name)).convert("RGB")
      self.img_info.append({'width':int(img.width), 'height':int(img.height)})

  def get_img_info(self, index):
    # WARNING: original image_file.json has several pictures with false image size
    # use correct function to check the validity before training
    # it will take a while, you only need to do it once

    # correct_img_info(self.img_dir, self.image_file)
    return self.img_info[index]

  def get_groundtruth(self, index, evaluation=False, flip_img=False):
    img_info = self.get_img_info(index)
    w, h = img_info['width'], img_info['height']
    # important: recover original box from BOX_SCALE
    box = self.gt_boxes[index] / BOX_SCALE * max(w, h)
    box = torch.from_numpy(box).reshape(-1, 4)  # guard against no boxes
    if flip_img:
      new_xmin = w - box[:,2]
      new_xmax = w - box[:,0]
      box[:,0] = new_xmin
      box[:,2] = new_xmax
    target = BoxList(box, (w, h), 'xyxy') # xyxy

    target.add_field("labels", torch.from_numpy(self.gt_classes[index]))
    target.add_field("attributes", torch.from_numpy(self.gt_attributes[index]))

    relation = self.relationships[index].copy() # (num_rel, 3)
    if self.filter_duplicate_rels:
      # Filter out dupes!
      assert self.split == 'train'
      old_size = relation.shape[0]
      all_rel_sets = defaultdict(list)
      for (o0, o1, r) in relation:
        all_rel_sets[(o0, o1)].append(r)
      relation = [(k[0], k[1], np.random.choice(v)) for k,v in all_rel_sets.items()]
      relation = np.array(relation, dtype=np.int32)
        
    # add relation to target
    num_box = len(target)
    relation_map = torch.zeros((num_box, num_box), dtype=torch.int64)
    for i in range(relation.shape[0]):
      if relation_map[int(relation[i,0]), int(relation[i,1])] > 0:
        if (random.random() > 0.5):
          relation_map[int(relation[i,0]), int(relation[i,1])] = (relation[i,2])
      else:
        relation_map[int(relation[i,0]), int(relation[i,1])] = int(relation[i,2])
    target.add_field("relation", relation_map, is_triplet=True)

    if evaluation:
      target = target.clip_to_image(remove_empty=False)
      target.add_field("relation_tuple", torch.LongTensor(relation)) # for evaluation
      return target
    else:
      target = target.clip_to_image(remove_empty=True)
    return target

  def __len__(self):
    if self.custom_eval:
      return len(self.custom_files)
    return len(self.filenames)
  
class VGGraph(data.Dataset):
  # need more modification
  # implemented into Maskrnn graph generation
  def __init__(self, root, load_in_mem=None, split=None, img_dir=None, roidb_file=None, dict_file=None, image_file=None, transform=None, 
        filter_empty_rels=True, num_im=-1, num_val_im=5000,
        filter_duplicate_rels=True, filter_non_overlap=True, flip_aug=False, custom_eval=False, custom_path='', mode='gen+graph', loader = default_loader):
    """
    Torch dataset for VisualGenome
    Parameters:
      split: Must be train, test, or val
      img_dir: folder containing all vg images
      roidb_file:  HDF5 containing the GT boxes, classes, and relationships
      dict_file: JSON Contains mapping of classes/relationships to words
      image_file: HDF5 containing image filenames
      filter_empty_rels: True if we filter out images without relationships between
            boxes. One might want to set this to false if training a detector.
      filter_duplicate_rels: Whenever we see a duplicate relationship we'll sample instead
      num_im: Number of images in the entire dataset. -1 for all images.
      num_val_im: Number of images in the validation set (must be less than num_im
      unless num_im is -1.)
    """


    assert split in {'train', 'val', 'test'}
    
    self.split = split
    self.img_dir = img_dir
    self.dict_file = dict_file
    self.roidb_file = roidb_file
    self.image_file = image_file
    self.filter_non_overlap = filter_non_overlap and self.split == 'train'
    self.filter_duplicate_rels = filter_duplicate_rels and self.split == 'train'
    self.transforms = transform
    self.mode = mode
    self.ind_to_classes, self.ind_to_predicates, self.ind_to_attributes = load_info(dict_file) # contiguous 151, 51 containing __background__
    self.categories = {i : self.ind_to_classes[i] for i in range(len(self.ind_to_classes))}
    self.loader = default_loader
    self.custom_eval = custom_eval
    
    self.filenames, self.img_info = load_image_filenames(img_dir, image_file) # length equals to split_mask

    if self.custom_eval:
      self.get_custom_imgs(custom_path)
    else:
      self.split_mask, self.gt_boxes, self.gt_classes, self.gt_attributes, self.relationships = load_graphs(
          self.roidb_file, self.split, num_im, num_val_im=num_val_im,
          filter_empty_rels=filter_empty_rels,
          filter_non_overlap=self.filter_non_overlap,
      )
      
      
      self.filenames = [self.filenames[i] for i in np.where(self.split_mask)[0]]
      self.img_info = [self.img_info[i] for i in np.where(self.split_mask)[0]]

      self.graphs = load_graph_matrix(self.gt_classes, self.gt_attributes, self.relationships, self.ind_to_classes, self.ind_to_attributes, self.ind_to_predicates)

      # min number of nodes
      self.K = self.graphs[3]
      # max number of nodes
      self.K_ = self.graphs[4] + 2
      self.K_P = self.graphs[-2]
      self.graph_data = self.graphs[-1]
          

  def __getitem__(self, index):
    img = self.loader(self.filenames[index])
    
    # graph: np.array(V), np.array(A), E, K, L, R, P
    V = self.graphs[0][index]
    A = self.graphs[1][index]
    E = self.graphs[2][index]
    num_nodes = A.shape[0]
    # num_edges = self.graphs[]
    A_ = torch.zeros((self.K_, self.K_))
    V_ = torch.zeros((self.K_, self.K_))
    # V_ = torch.zeros((1))

    E_ = torch.zeros((self.K_, self.K))

    A_[:num_nodes, :num_nodes] = torch.FloatTensor(A)
    
    V_ = torch.from_numpy(np.asarray(V, dtype=np.float))
    # V_[:num_nodes, :num_nodes] = torch.FloatTensor(V)
    E_[:num_nodes, :] = torch.FloatTensor(E)
    
    # label information
    C_L = self.graphs[5][index]
    C_R = self.graphs[6][index]
    C_P = self.graphs[7][index]
    num_edges = C_P.shape[0]
    num_nodes = C_L.shape[1]
    C_L_ = torch.zeros((self.K_)).long()
    C_R_ = torch.zeros((10, self.K_)).long()
    C_P_ = torch.zeros((self.K_P)).long()


    C_L_[:num_nodes] = torch.LongTensor(C_L)
    C_R_[:, :num_nodes] = torch.LongTensor(C_R)
    C_P_[:num_edges] = torch.LongTensor(C_P)
    
    G = self.graph_data[index]
    
    

    if self.transforms is not None:
      if self.mode=='generative':
        img = self.transforms(img)
        for i in self.gt_classes[index]:
          if i == 0:
           continue
          else:
            target = int(i-1)
        return img, target
      elif self.mode == 'detection':
        img, target = self.transforms(img, target)
        return img, target
      elif self.mode == 'gen+graph':
        img = self.transforms(img)
        return img, (E_, A_, V_, C_L_, C_R_, C_P_), index

  def __len__(self):
    if self.custom_eval:
      return len(self.custom_files)
    return len(self.img_info)
    


  def get_statistics(self):
    fg_matrix, bg_matrix = get_VG_statistics(img_dir=self.img_dir, roidb_file=self.roidb_file, dict_file=self.dict_file,
                      image_file=self.image_file, must_overlap=True)
    eps = 1e-3
    bg_matrix += 1
    fg_matrix[:, :, 0] = bg_matrix
    pred_dist = np.log(fg_matrix / fg_matrix.sum(2)[:, :, None] + eps)

    result = {
      'fg_matrix': torch.from_numpy(fg_matrix),
      'pred_dist': torch.from_numpy(pred_dist).float(),
      'obj_classes': self.ind_to_classes,
      'rel_classes': self.ind_to_predicates,
      'att_classes': self.ind_to_attributes,
    }
    return result

  def get_custom_imgs(self, path):
    self.custom_files = []
    self.img_info = []
    for file_name in os.listdir(path):
      self.custom_files.append(os.path.join(path, file_name))
      img = Image.open(os.path.join(path, file_name)).convert("RGB")
      self.img_info.append({'width':int(img.width), 'height':int(img.height)})

  def get_img_info(self, index):
    # WARNING: original image_file.json has several pictures with false image size
    # use correct function to check the validity before training
    # it will take a while, you only need to do it once

    # correct_img_info(self.img_dir, self.image_file)
    return self.img_info[index]

  def get_groundtruth(self, index, evaluation=False, flip_img=False):
    img_info = self.get_img_info(index)
    w, h = img_info['width'], img_info['height']
    # important: recover original box from BOX_SCALE
    box = self.gt_boxes[index] / BOX_SCALE * max(w, h)
    box = torch.from_numpy(box).reshape(-1, 4)  # guard against no boxes
    if flip_img:
      new_xmin = w - box[:,2]
      new_xmax = w - box[:,0]
      box[:,0] = new_xmin
      box[:,2] = new_xmax
    target = BoxList(box, (w, h), 'xyxy') # xyxy

    target.add_field("labels", torch.from_numpy(self.gt_classes[index]))
    target.add_field("attributes", torch.from_numpy(self.gt_attributes[index]))

    relation = self.relationships[index].copy() # (num_rel, 3)
    if self.filter_duplicate_rels:
      # Filter out dupes!
      assert self.split == 'train'
      old_size = relation.shape[0]
      all_rel_sets = defaultdict(list)
      for (o0, o1, r) in relation:
        all_rel_sets[(o0, o1)].append(r)
      relation = [(k[0], k[1], np.random.choice(v)) for k,v in all_rel_sets.items()]
      relation = np.array(relation, dtype=np.int32)
        
    # add relation to target
    num_box = len(target)
    relation_map = torch.zeros((num_box, num_box), dtype=torch.int64)
    for i in range(relation.shape[0]):
      if relation_map[int(relation[i,0]), int(relation[i,1])] > 0:
        if (random.random() > 0.5):
          relation_map[int(relation[i,0]), int(relation[i,1])] = (relation[i,2])
      else:
        relation_map[int(relation[i,0]), int(relation[i,1])] = int(relation[i,2])
    target.add_field("relation", relation_map, is_triplet=True)

    if evaluation:
      target = target.clip_to_image(remove_empty=False)
      target.add_field("relation_tuple", torch.LongTensor(relation)) # for evaluation
      return target
    else:
      target = target.clip_to_image(remove_empty=True)
    return target

  def __len__(self):
    if self.custom_eval:
      return len(self.custom_files)
    return len(self.filenames)

class GraphDataset(data.Dataset):
  '''
  merely graph set of the VGdataset
  '''
  def __init__(self, vgdataset=None, load_in_mem=None, split=None, img_dir=None, roidb_file=None, dict_file=None, image_file=None,filter_empty_rels=True, num_im=-1, num_val_im=5000, filter_duplicate_rels=True, filter_non_overlap=True, flip_aug=False, custom_eval=False, custom_path='', loader = default_loader, device='cuda'):
    self.device = device
    if vgdataset is None:
      assert split in {'train', 'val', 'test'}
      self.split = split
      self.img_dir = img_dir
      self.dict_file = dict_file
      self.roidb_file = roidb_file
      self.image_file = image_file
      self.filter_non_overlap = filter_non_overlap and self.split == 'train'
      self.filter_duplicate_rels = filter_duplicate_rels and self.split == 'train'
      self.transforms = transform
      self.mode = mode
      self.ind_to_classes, self.ind_to_predicates, self.ind_to_attributes = load_info(dict_file) # contiguous 151, 51 containing __background__
      self.categories = {i : self.ind_to_classes[i] for i in range(len(self.ind_to_classes))}
      self.loader = default_loader
      self.custom_eval = custom_eval
    
      self.filenames, self.img_info = load_image_filenames(img_dir, image_file) # length equals to split_mask

      if self.custom_eval:
        self.get_custom_imgs(custom_path)
      else:
        self.split_mask, self.gt_boxes, self.gt_classes, self.gt_attributes, self.relationships = load_graphs(
            self.roidb_file, self.split, num_im, num_val_im=num_val_im,
            filter_empty_rels=filter_empty_rels,
            filter_non_overlap=self.filter_non_overlap,
        )
        self.filenames = [self.filenames[i] for i in np.where(self.split_mask)[0]]
        self.img_info = [self.img_info[i] for i in np.where(self.split_mask)[0]]
        self.graphs = load_graph_matrix(self.gt_classes, self.gt_attributes, self.relationships, self.ind_to_classes, self.ind_to_attributes, self.ind_to_predicates)
        self.K = graphs[3]
        self.K_ = graphs[4] + 2
        self.K_P = self.graphs[-2]
        self.graph_data = self.graphs[-1]

    else:
      self.custom_eval = custom_eval
      self.graphs = vgdataset.graphs
      self.img_info = vgdataset.img_info
      self.K_ = vgdataset.K_
      self.K = vgdataset.K
      self.K_P = vgdataset.K_P
      self.graph_data = vgdataset.graph_data

        


  def __getitem__(self, index):
    
    #  np.array(V), np.array(A), E, K, K_, L, R, P, K_P, graph_data
    V = self.graphs[0][index]
    A = torch.from_numpy(self.graphs[1][index])
    E = torch.from_numpy(self.graphs[2][index])
    num_nodes = A.shape[0]
    # label information
    C_L =  torch.from_numpy(self.graphs[5][index])
    C_R =  torch.from_numpy(self.graphs[6][index])
    C_P =  torch.from_numpy(self.graphs[7][index])
    # G = self.graph_data[index]
    assert num_nodes == C_L.shape[1]

    return (A, V, E, C_L, C_R, C_P, self.K_P, index)
  
  def __len__(self):
    if self.custom_eval:
      return len(self.custom_files)
    return len(self.graphs[0])

class VGCE(data.Dataset):
  # Multiclass dataset for baseline
  def __init__(self, root, load_in_mem=None, split=None, img_dir=None, roidb_file=None, dict_file=None, image_file=None, transform=None, 
        filter_empty_rels=True, num_im=-1, num_val_im=5000,
        filter_duplicate_rels=True, filter_non_overlap=True, flip_aug=False, custom_eval=False, custom_path='', mode='gen+graph', loader = default_loader):
    assert split in {'train', 'val', 'test'}
    self.split = split
    self.img_dir = img_dir
    self.dict_file = dict_file
    self.roidb_file = roidb_file
    self.image_file = image_file
    self.filter_non_overlap = filter_non_overlap and self.split == 'train'
    self.filter_duplicate_rels = filter_duplicate_rels and self.split == 'train'
    self.transforms = transform
    self.mode = mode
    self.ind_to_classes, self.ind_to_predicates, self.ind_to_attributes = load_info(dict_file) # contiguous 151, 51 containing __background__
    self.categories = {i : self.ind_to_classes[i] for i in range(len(self.ind_to_classes))}
    self.loader = default_loader
    self.custom_eval = custom_eval

    self.filenames, self.img_info = load_image_filenames(img_dir, image_file)

    if self.custom_eval:
        self.get_custom_imgs(custom_path)
    else:
      self.split_mask, self.gt_boxes, self.gt_classes, self.gt_attributes, self.relationships = load_graphs(
          self.roidb_file, self.split, num_im, num_val_im=num_val_im,
          filter_empty_rels=filter_empty_rels,
          filter_non_overlap=self.filter_non_overlap,
      )
  
  def __getitem__(self, index):
    if self.custom_eval:
      img = Image.open(self.custom_files[index]).convert("RGB")
      target = torch.LongTensor([-1])
      if self.transforms is not None:
        img, target = self.transforms(img, target)
      return img, target, index
    img = Image.open(self.filenames[index]).convert("RGB")
    if img.size[0] != self.img_info[index]['width'] or img.size[1] != self.img_info[index]['height']:
      print('='*20, ' ERROR index ', str(index), ' ', str(img.size), ' ', str(self.img_info[index]['width']), ' ', str(self.img_info[index]['height']), ' ', '='*20)  
    flip_img = (random.random() > 0.5) and self.flip_aug and (self.split == 'train')
    target = self.get_groundtruth(index, flip_img)
    if flip_img:
      img = img.transpose(method=Image.FLIP_LEFT_RIGHT)
    if self.transforms is not None:
      img, target = self.transforms(img, target)
    return img, target, index

def get_VG_statistics(img_dir, roidb_file, dict_file, image_file, must_overlap=True):
  train_data = VGDataset(split='train', img_dir=img_dir, roidb_file=roidb_file, 
                      dict_file=dict_file, image_file=image_file, num_val_im=5000, 
                      filter_duplicate_rels=False)
  num_obj_classes = len(train_data.ind_to_classes)
  num_rel_classes = len(train_data.ind_to_predicates)
  fg_matrix = np.zeros((num_obj_classes, num_obj_classes, num_rel_classes), dtype=np.int64)
  bg_matrix = np.zeros((num_obj_classes, num_obj_classes), dtype=np.int64)

  for ex_ind in tqdm(range(len(train_data))):
    gt_classes = train_data.gt_classes[ex_ind].copy()
    gt_relations = train_data.relationships[ex_ind].copy()
    gt_boxes = train_data.gt_boxes[ex_ind].copy()

    # For the foreground, we'll just look at everything
    o1o2 = gt_classes[gt_relations[:, :2]]
    for (o1, o2), gtr in zip(o1o2, gt_relations[:,2]):
      fg_matrix[o1, o2, gtr] += 1
    # For the background, get all of the things that overlap.
    o1o2_total = gt_classes[np.array(
      box_filter(gt_boxes, must_overlap=must_overlap), dtype=int)]
    for (o1, o2) in o1o2_total:
      bg_matrix[o1, o2] += 1

  return fg_matrix, bg_matrix
    

def box_filter(boxes, must_overlap=False):
  """ Only include boxes that overlap as possible relations. 
  If no overlapping boxes, use all of them."""
  n_cands = boxes.shape[0]

  overlaps = bbox_overlaps(boxes.astype(np.float), boxes.astype(np.float), to_move=0) > 0
  np.fill_diagonal(overlaps, 0)

  all_possib = np.ones_like(overlaps, dtype=np.bool)
  np.fill_diagonal(all_possib, 0)

  if must_overlap:
    possible_boxes = np.column_stack(np.where(overlaps))

    if possible_boxes.size == 0:
      possible_boxes = np.column_stack(np.where(all_possib))
  else:
    possible_boxes = np.column_stack(np.where(all_possib))
  return possible_boxes

def bbox_overlaps(boxes1, boxes2, to_move=1):
  """
  boxes1 : numpy, [num_obj, 4] (x1,y1,x2,y2)
  boxes2 : numpy, [num_obj, 4] (x1,y1,x2,y2)
  """
  #print('boxes1: ', boxes1.shape)
  #print('boxes2: ', boxes2.shape)
  num_box1 = boxes1.shape[0]
  num_box2 = boxes2.shape[0]
  lt = np.maximum(boxes1.reshape([num_box1, 1, -1])[:,:,:2], boxes2.reshape([1, num_box2, -1])[:,:,:2]) # [N,M,2]
  rb = np.minimum(boxes1.reshape([num_box1, 1, -1])[:,:,2:], boxes2.reshape([1, num_box2, -1])[:,:,2:]) # [N,M,2]

  wh = (rb - lt + to_move).clip(min=0)  # [N,M,2]
  inter = wh[:, :, 0] * wh[:, :, 1]  # [N,M]

  return inter

def correct_img_info(img_dir, image_file):
  with open(image_file, 'r') as f:
    data = json.load(f)
  for i in range(len(data)):
    img = data[i]
    basename = '{}.jpg'.format(img['image_id'])
    filename = os.path.join(img_dir, basename)
    img_data = Image.open(filename).convert("RGB")
    if img['width'] != img_data.size[0] or img['height'] != img_data.size[1]:
      print('--------- False id: ', i, '---------')
      print(img_data.size)
      print(img)
      data[i]['width'] = img_data.size[0]
      data[i]['height'] = img_data.size[1]
  with open(image_file, 'w') as outfile:  
    json.dump(data, outfile)

def load_info(dict_file, add_bg=True):
  """
  Loads the file containing the visual genome label meanings
  """
  info = json.load(open(dict_file, 'r'))
  if add_bg:
    info['label_to_idx']['__background__'] = 0
    info['predicate_to_idx']['__background__'] = 0
    info['attribute_to_idx']['__background__'] = 0

  class_to_ind = info['label_to_idx']
  predicate_to_ind = info['predicate_to_idx']
  attribute_to_ind = info['attribute_to_idx']
  ind_to_classes = sorted(class_to_ind, key=lambda k: class_to_ind[k])
  ind_to_predicates = sorted(predicate_to_ind, key=lambda k: predicate_to_ind[k])
  ind_to_attributes = sorted(attribute_to_ind, key=lambda k: attribute_to_ind[k])

  return ind_to_classes, ind_to_predicates, ind_to_attributes


def load_image_filenames(img_dir, image_file):
  """
  Loads the image filenames from visual genome from the JSON file that containsthem.
  This matches the preprocessing in scene-graph-TF-release/data_toolsvg_to_imdb.py.
  Parameters:
    image_file: JSON file. Elements contain the param "image_id".
    img_dir: directory where the VisualGenome images are located
  Return: 
    List of filenames corresponding to the good images
  """
  with open(image_file, 'r') as f:
    im_data = json.load(f)

  corrupted_ims = ['1592.jpg', '1722.jpg', '4616.jpg', '4617.jpg']
  fns = []
  img_info = []
  for i, img in enumerate(im_data):
    basename = '{}.jpg'.format(img['image_id'])
    if basename in corrupted_ims:
      continue

    filename = os.path.join(img_dir, basename)
    if os.path.exists(filename):
      fns.append(filename)
      img_info.append(img)
  assert len(fns) == 108073
  assert len(img_info) == 108073
  return fns, img_info


def load_graphs(roidb_file, split, num_im, num_val_im, filter_empty_rels, filter_non_overlap):
  """
  Load the file containing the GT boxes and relations, as well as the datasetsplit
  Parameters:
    roidb_file: HDF5
    split: (train, val, or test)
    num_im: Number of images we want
    num_val_im: Number of validation images
    filter_empty_rels: (will be filtered otherwise.)
      filter_non_overlap: If training, filter images that dont overlap.
  Return: 
    image_index: numpy array corresponding to the index of images we're using
    boxes: List where each element is a [num_gt, 4] array of ground 
              truth boxes (x1, y1, x2, y2)
    gt_classes: List where each element is a [num_gt] array of classes
    relationships: List where each element is a [num_r, 3] array of 
              (box_ind_1, box_ind_2, predicate) relationships
  """
  roi_h5 = h5py.File(roidb_file, 'r')
  data_split = roi_h5['split'][:]
  split_flag = 2 if split == 'test' else 0
  split_mask = data_split == split_flag

  # Filter out images without bounding boxes
  split_mask &= roi_h5['img_to_first_box'][:] >= 0
  if filter_empty_rels:
    split_mask &= roi_h5['img_to_first_rel'][:] >= 0

  image_index = np.where(split_mask)[0]
  if num_im > -1:
    image_index = image_index[:num_im]
  if num_val_im > 0:
    if split == 'val':
      image_index = image_index[:num_val_im]
    elif split == 'train':
      image_index = image_index[num_val_im:]


  split_mask = np.zeros_like(data_split).astype(bool)
  split_mask[image_index] = True

  # Get box information
  all_labels = roi_h5['labels'][:, 0]
  all_attributes = roi_h5['attributes'][:, :]
  all_boxes = roi_h5['boxes_{}'.format(BOX_SCALE)][:]  # cx,cy,w,h
  assert np.all(all_boxes[:, :2] >= 0)  # sanity check
  assert np.all(all_boxes[:, 2:] > 0)  # no empty box

  # convert from xc, yc, w, h to x1, y1, x2, y2
  all_boxes[:, :2] = all_boxes[:, :2] - all_boxes[:, 2:] / 2
  all_boxes[:, 2:] = all_boxes[:, :2] + all_boxes[:, 2:]

  im_to_first_box = roi_h5['img_to_first_box'][split_mask]
  im_to_last_box = roi_h5['img_to_last_box'][split_mask]
  im_to_first_rel = roi_h5['img_to_first_rel'][split_mask]
  im_to_last_rel = roi_h5['img_to_last_rel'][split_mask]

  # load relation labels
  _relations = roi_h5['relationships'][:]
  _relation_predicates = roi_h5['predicates'][:, 0]
  assert (im_to_first_rel.shape[0] == im_to_last_rel.shape[0])
  assert (_relations.shape[0] == _relation_predicates.shape[0])  # sanity check

  # Get everything by image.
  boxes = []
  gt_classes = []
  gt_attributes = []
  relationships = []
  for i in range(len(image_index)):
    i_obj_start = im_to_first_box[i]
    i_obj_end = im_to_last_box[i]
    i_rel_start = im_to_first_rel[i]
    i_rel_end = im_to_last_rel[i]

    boxes_i = all_boxes[i_obj_start : i_obj_end + 1, :]
    gt_classes_i = all_labels[i_obj_start : i_obj_end + 1]
    gt_attributes_i = all_attributes[i_obj_start : i_obj_end + 1, :]

    if i_rel_start >= 0:
      predicates = _relation_predicates[i_rel_start : i_rel_end + 1]
      obj_idx = _relations[i_rel_start : i_rel_end + 1] - i_obj_start # rangeis [0, num_box)
      assert np.all(obj_idx >= 0)
      assert np.all(obj_idx < boxes_i.shape[0])
      rels = np.column_stack((obj_idx, predicates)) # (num_rel, 3),representing sub, obj, and pred
    else:
      assert not filter_empty_rels
      rels = np.zeros((0, 3), dtype=np.int32)

    if filter_non_overlap:
      assert split == 'train'
      # construct BoxList object to apply boxlist_iou method
      # give a useless (height=0, width=0)
      boxes_i_obj = BoxList(boxes_i, (1000, 1000), 'xyxy')
      inters = boxlist_iou(boxes_i_obj, boxes_i_obj)
      rel_overs = inters[rels[:, 0], rels[:, 1]]
      inc = np.where(rel_overs > 0.0)[0]

      if inc.size > 0:
        rels = rels[inc]
      else:
        split_mask[image_index[i]] = 0
        continue

    boxes.append(boxes_i)
    gt_classes.append(gt_classes_i)
    gt_attributes.append(gt_attributes_i)
    relationships.append(rels)

  return split_mask, boxes, gt_classes, gt_attributes, relationships

def load_graph_matrix(classes, attributes, relationships, classes_dict, attributes_dict, relationships_dict):
  graph_data = []
  max_nodes = 0
  min_nodes = 1000
  classlabel_data = []
  attribute_data = []
  relationtype_data = []
  max_relations = 0
  attr_name = ['attr0', 'attr1', 'attr2', 'attr3', 'attr4', 'attr5', 'attr6', 'attr7', 'attr8', 'attr9']
  for idx, edges in tqdm(enumerate(relationships)):
    # G = nx.DiGraph()
    G = nx.Graph()
    # nodes are the boxes
    # label and attribute are both attributes of the node
    # relationships are the edges
    assert len(classes[idx]) == len(attributes[idx])
    L = np.zeros((1, len(classes[idx])))
    R = np.zeros((10, len(classes[idx])))
    P = np.zeros((len(edges)))
    nodes_list = []
    for i, nd in enumerate(classes[idx]):
      
      # at most have 10 attributes
      attr = attributes[idx][i]
      attrs = {'name':classes_dict[nd].strip('_')}
      node_label = i
      for aidx, a in enumerate(attr):
        if a != 0:
          attrs.update({attr_name[aidx]: attributes_dict[a]})
        else:
          continue
      
      nodes_list.append((node_label, attrs))
      
      L[0, i] = nd
      R[:, i] = attr
      if len(classes[idx]) > max_nodes:
        max_nodes = len(classes[idx])
      if len(classes[idx]) < min_nodes:
        min_nodes = len(classes[idx])
      if len(edges) > max_relations:
        max_relations = len(edges)
    
    G.add_nodes_from(nodes_list)
    rel_with_pred = []
    for i, rel in enumerate(edges):
      rel1 = rel[0]
      rel2 = rel[1]
      rs = relationships_dict[rel[2]]

      rela = (rel1, rel2, {'pred_type': rs})
      rel_with_pred.append(rela)
      P[i] = rel[2]
    
    G.add_edges_from(rel_with_pred)
    assert len(G.nodes) == len(nodes_list)

            

    graph_data.append(G)
    classlabel_data.append(L)
    attribute_data.append(R)
    relationtype_data.append(P)

  A = [nx.to_numpy_array(g) for g in graph_data]
  V = [len(a) for a in A]
  L = classlabel_data
  R = attribute_data
  P = relationtype_data
  print('%'*20)
  print('the max number of nodes: ' + str(max_nodes))
  print('%'*20)
  print('the min number of nodes: ' + str(min_nodes))
  print('%'*20)
  print('the max number of relationships: ' + str(max_relations))
  print('%'*20)
  E = np.array([compute_unnormalized_laplacian_eigenmaps(a) for a in A])      
  
  K = min_nodes
  K_ = max_nodes
  K_P = max_relations
  # K = 2
  E = np.array([e[:, :K] for e in E])

  # C = (L, R, P)

  return np.array(V), np.array(A), E, K, K_, L, R, P, K_P, graph_data
  

    


    

  
